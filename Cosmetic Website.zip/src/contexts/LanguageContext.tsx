import { createContext, useContext, useState, ReactNode } from "react";

export type Language = "en" | "vi";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  formatPrice: (price: number) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Exchange rate: 1 USD = 25,000 VND (approximate)
const USD_TO_VND = 25000;

// Translations
const translations: Record<Language, Record<string, string>> = {
  en: {
    // Navbar
    "nav.home": "Home",
    "nav.shop": "Shop",
    "nav.about": "About",
    "nav.blog": "Blog",
    "nav.contact": "Contact",
    "nav.search": "Search products...",
    "nav.searchPlaceholder": "Search here",
    "nav.cart": "Cart",
    "nav.login": "Login",
    "nav.register": "Register",
    "nav.logout": "Logout",
    "nav.adminDashboard": "Admin Dashboard",
    "nav.myAccount": "My Account",
    "nav.profile": "Profile",
    "nav.orders": "Order History",
    
    // Hero
    "hero.title": "Discover Your Natural Beauty",
    "hero.subtitle": "Premium cosmetics crafted with natural ingredients for radiant, healthy skin",
    "hero.shopNow": "Shop Now",
    "hero.learnMore": "Learn More",
    
    // Categories
    "categories.title": "Shop by Category",
    "categories.subtitle": "Explore our curated selection",
    
    // Featured Products
    "products.featured": "Featured Products",
    "products.subtitle": "Our most-loved products, handpicked for you",
    "products.addToCart": "Add to Cart",
    "products.viewAll": "View All Products",
    "products.new": "New",
    "products.bestSeller": "Best Seller",
    "products.sale": "Sale",
    "products.reviews": "reviews",
    
    // About
    "about.title": "About Beauté",
    "about.subtitle": "Luxury Cosmetics for the Modern Woman",
    "about.description": "At Beauté, we believe in the power of natural beauty enhanced by premium, scientifically-backed skincare. Our products are carefully formulated with the finest natural ingredients, combining traditional beauty wisdom with modern innovation.",
    "about.naturalIngredients": "Natural Ingredients",
    "about.crueltyFree": "Cruelty Free",
    "about.dermatologistTested": "Dermatologist Tested",
    "about.premiumProducts": "Premium Products",
    "about.happyCustomers": "Happy Customers",
    "about.naturalIngredientsPercent": "Natural Ingredients",
    "about.customerSupport": "Customer Support",
    
    // Newsletter
    "newsletter.title": "Stay Connected",
    "newsletter.subtitle": "Join our community and get exclusive offers, beauty tips, and new arrivals delivered to your inbox.",
    "newsletter.emailPlaceholder": "Enter your email",
    "newsletter.subscribe": "Subscribe",
    "newsletter.companyInfo": "Nourish Skin Caring",
    "newsletter.contact": "Contact",
    "newsletter.email": "Email",
    "newsletter.address": "Address",
    "newsletter.newsResources": "News, resources and insights - delivered to your inbox. Subscribe.",
    "newsletter.leaveEmail": "Leave your email",
    "newsletter.privacyAgreement": "By checking this box, you agree to the processing of data in accordance with Privacy Policy.",
    "newsletter.successMessage": "Subscription successful! Thank you for subscribing.",
    "newsletter.errorEmail": "Please enter your email",
    "newsletter.errorPrivacy": "Please agree to the privacy policy",
    
    // Footer
    "footer.shopTitle": "Shop",
    "footer.skincare": "Skincare",
    "footer.makeup": "Makeup",
    "footer.fragrance": "Fragrance",
    "footer.bodycare": "Body Care",
    "footer.haircare": "Hair Care",
    "footer.customerCareTitle": "Customer Care",
    "footer.shippingInfo": "Shipping Information",
    "footer.returns": "Returns & Exchanges",
    "footer.faq": "FAQ",
    "footer.contactUs": "Contact Us",
    "footer.trackOrder": "Track Order",
    "footer.aboutTitle": "About Beauté",
    "footer.ourStory": "Our Story",
    "footer.sustainability": "Sustainability",
    "footer.careers": "Careers",
    "footer.press": "Press",
    "footer.blog": "Blog",
    "footer.legalTitle": "Legal",
    "footer.privacyPolicy": "Privacy Policy",
    "footer.termsOfService": "Terms of Service",
    "footer.cookiePolicy": "Cookie Policy",
    "footer.accessibility": "Accessibility",
    "footer.siteMap": "Site Map",
    "footer.followUs": "Follow Us",
    "footer.copyright": "© 2024 Beauté Cosmetics. All rights reserved.",
    
    // Cart
    "cart.title": "Shopping Cart",
    "cart.empty": "Your cart is empty",
    "cart.emptyMessage": "Start shopping to add items to your cart",
    "cart.continueShopping": "Continue Shopping",
    "cart.remove": "Remove",
    "cart.subtotal": "Subtotal",
    "cart.shipping": "Shipping",
    "cart.free": "Free",
    "cart.tax": "Tax",
    "cart.total": "Total",
    "cart.checkout": "Proceed to Checkout",
    
    // Checkout
    "checkout.title": "Checkout",
    "checkout.success": "Payment Successful!",
    "checkout.successMessage": "Thank you for your order. Redirecting to homepage...",
    "checkout.shippingInfo": "Shipping Information",
    "checkout.fullName": "Full Name",
    "checkout.phone": "Phone",
    "checkout.email": "Email",
    "checkout.address": "Address",
    "checkout.city": "City",
    "checkout.zipCode": "Zip Code",
    "checkout.paymentMethod": "Payment Method",
    "checkout.completePayment": "Complete Payment",
    "checkout.processing": "Processing...",
    
    // Auth
    "auth.login": "Login",
    "auth.register": "Register",
    "auth.createAccount": "Create Account",
    "auth.alreadyHaveAccount": "Already have an account?",
    "auth.dontHaveAccount": "Don't have an account?",
    "auth.loginHere": "Login here",
    "auth.registerHere": "Register here",
    "auth.password": "Password",
    "auth.name": "Full Name",
    "auth.age": "Age",
    "auth.occupation": "Occupation",
    "auth.preferences": "Product Preferences (Select your interests)",
    
    // Login/Register Page
    "auth.email": "Email",
    "auth.invalidCredentials": "Invalid email or password",
    "auth.demoAccounts": "Demo Accounts:",
    "auth.adminAccount": "Admin: admin@beaute.com / admin123",
    "auth.orRegister": "Or register your own account",
    "auth.loginButton": "Login",
    "auth.or": "Or",
    "auth.loginWithGoogle": "Login with Google",
    "auth.registerButton": "Register",
    "auth.confirmPassword": "Confirm Password",
    "auth.passwordMismatch": "Passwords do not match",
    "auth.emailExists": "Email already exists",
    "auth.registrationSuccess": "Registration successful! Redirecting to login...",
    "auth.phone": "Phone",
    "auth.address": "Address",
    "auth.required": "*",
    
    // Common
    "common.loading": "Loading...",
    "common.search": "Search",
    "common.filter": "Filter",
    "common.sort": "Sort",
    "common.price": "Price",
    "common.color": "Color",
    "common.size": "Size",
    "common.quantity": "Quantity",
    "common.inStock": "In Stock",
    "common.outOfStock": "Out of Stock",
    "common.clearFilters": "Clear Filters",
    "common.all": "All",
    "common.category": "Category",
    "common.priceRange": "Price Range",
    "common.material": "Material / Features",
    "common.viewDetails": "View Details",
    "common.addToWishlist": "Add to Wishlist",
    "common.removeFromWishlist": "Remove from Wishlist",
    "common.buyNow": "Buy Now",
    "common.showing": "Showing",
    "common.products": "products",
    "common.noProducts": "No products found",
    "common.tryDifferentFilters": "Please try different filters",
    
    // Toast messages
    "toast.addedToWishlist": "Added to Wishlist",
    "toast.removedFromWishlist": "Removed from Wishlist",
    "toast.addedToCart": "Added to Cart",
    
    // Sort options
    "sort.featured": "Featured",
    "sort.priceLowHigh": "Price: Low to High",
    "sort.priceHighLow": "Price: High to Low",
    "sort.nameAZ": "Name: A-Z",
    "sort.nameZA": "Name: Z-A",
    "sort.rating": "Highest Rated",
  },
  vi: {
    // Navbar
    "nav.home": "Trang Chủ",
    "nav.shop": "Mua Sắm",
    "nav.about": "Giới Thiệu",
    "nav.blog": "Blog",
    "nav.contact": "Liên Hệ",
    "nav.search": "Tìm kiếm sản phẩm...",
    "nav.searchPlaceholder": "Tìm kiếm tại đây",
    "nav.cart": "Giỏ Hàng",
    "nav.login": "Đăng Nhập",
    "nav.register": "Đăng Ký",
    "nav.logout": "Đăng Xuất",
    "nav.adminDashboard": "Quản Trị",
    "nav.myAccount": "Tài Khoản",
    "nav.profile": "Thông Tin",
    "nav.orders": "Đơn Hàng",
    
    // Hero
    "hero.title": "Khám Phá Vẻ Đẹp Tự Nhiên",
    "hero.subtitle": "Mỹ phẩm cao cấp từ thiên nhiên cho làn da rạng rỡ, khỏe mạnh",
    "hero.shopNow": "Mua Ngay",
    "hero.learnMore": "Tìm Hiểu Thêm",
    
    // Categories
    "categories.title": "Danh Mục Sản Phẩm",
    "categories.subtitle": "Khám phá bộ sưu tập được tuyển chọn",
    
    // Featured Products
    "products.featured": "Sản Phẩm Nổi Bật",
    "products.subtitle": "Những sản phẩm được yêu thích nhất, chọn lọc cho bạn",
    "products.addToCart": "Thêm Vào Giỏ",
    "products.viewAll": "Xem Tất Cả",
    "products.new": "Mới",
    "products.bestSeller": "Bán Chạy",
    "products.sale": "Giảm Giá",
    "products.reviews": "đánh giá",
    
    // About
    "about.title": "Về Beauté",
    "about.subtitle": "Mỹ Phẩm Cao Cấp Cho Phụ Nữ Hiện Đại",
    "about.description": "Tại Beauté, chúng tôi tin vào sức mạnh của vẻ đẹp tự nhiên được nâng cao bởi các sản phẩm chăm sóc da cao cấp, được chứng minh khoa học. Sản phẩm của chúng tôi được điều chế cẩn thận từ những thành phần tự nhiên tốt nhất, kết hợp giữa trí tuệ làm đẹp truyền thống và sự đổi mới hiện đại.",
    "about.naturalIngredients": "Thành Phần Tự Nhiên",
    "about.crueltyFree": "Không Thử Nghiệm Động Vật",
    "about.dermatologistTested": "Kiểm Nghiệm Da Liễu",
    "about.premiumProducts": "Sản Phẩm Cao Cấp",
    "about.happyCustomers": "Khách Hàng Hài Lòng",
    "about.naturalIngredientsPercent": "Thành Phần Tự Nhiên",
    "about.customerSupport": "Hỗ Trợ Khách Hàng",
    
    // Newsletter
    "newsletter.title": "Kết Nối Cùng Chúng Tôi",
    "newsletter.subtitle": "Tham gia cộng đồng của chúng tôi để nhận ưu đãi độc quyền, mẹo làm đẹp và sản phẩm mới nhất.",
    "newsletter.emailPlaceholder": "Nhập email của bạn",
    "newsletter.subscribe": "Đăng Ký",
    "newsletter.companyInfo": "Nourish Skin Caring",
    "newsletter.contact": "Contact",
    "newsletter.email": "Email",
    "newsletter.address": "Address",
    "newsletter.newsResources": "News, resources and insights - delivered to your inbox. Subscribe.",
    "newsletter.leaveEmail": "Leave your email",
    "newsletter.privacyAgreement": "By checking this box, you agree to the processing of data in accordance with Privacy Policy.",
    "newsletter.successMessage": "Subscription successful! Thank you for subscribing.",
    "newsletter.errorEmail": "Please enter your email",
    "newsletter.errorPrivacy": "Please agree to the privacy policy",
    
    // Footer
    "footer.shopTitle": "Mua Sắm",
    "footer.skincare": "Chăm Sóc Da",
    "footer.makeup": "Trang Điểm",
    "footer.fragrance": "Nước Hoa",
    "footer.bodycare": "Chăm Sóc Cơ Thể",
    "footer.haircare": "Chăm Sóc Tóc",
    "footer.customerCareTitle": "Chăm Sóc Khách Hàng",
    "footer.shippingInfo": "Thông Tin Giao Hàng",
    "footer.returns": "Đổi Trả Hàng",
    "footer.faq": "Câu Hỏi Thường Gặp",
    "footer.contactUs": "Liên Hệ",
    "footer.trackOrder": "Theo Dõi Đơn Hàng",
    "footer.aboutTitle": "Về Beauté",
    "footer.ourStory": "Câu Chuyện Của Chúng Tôi",
    "footer.sustainability": "Bền Vững",
    "footer.careers": "Tuyển Dụng",
    "footer.press": "Báo Chí",
    "footer.blog": "Blog",
    "footer.legalTitle": "Pháp Lý",
    "footer.privacyPolicy": "Chính Sách Bảo Mật",
    "footer.termsOfService": "Điều Khoản Dịch Vụ",
    "footer.cookiePolicy": "Chính Sách Cookie",
    "footer.accessibility": "Khả Năng Tiếp Cận",
    "footer.siteMap": "Sơ Đồ Trang",
    "footer.followUs": "Theo Dõi Chúng Tôi",
    "footer.copyright": "© 2024 Beauté Cosmetics. Bảo lưu mọi quyền.",
    
    // Cart
    "cart.title": "Giỏ Hàng",
    "cart.empty": "Giỏ hàng trống",
    "cart.emptyMessage": "Bắt đầu mua sắm để thêm sản phẩm vào giỏ hàng",
    "cart.continueShopping": "Tiếp Tục Mua Sắm",
    "cart.remove": "Xóa",
    "cart.subtotal": "Tạm Tính",
    "cart.shipping": "Phí Vận Chuyển",
    "cart.free": "Miễn Phí",
    "cart.tax": "Thuế",
    "cart.total": "Tổng Cộng",
    "cart.checkout": "Thanh Toán",
    
    // Checkout
    "checkout.title": "Thanh Toán",
    "checkout.success": "Thanh Toán Thành Công!",
    "checkout.successMessage": "Cảm ơn bạn đã đặt hàng. Đang chuyển về trang chủ...",
    "checkout.shippingInfo": "Thông Tin Giao Hàng",
    "checkout.fullName": "Họ Và Tên",
    "checkout.phone": "Số Điện Thoại",
    "checkout.email": "Email",
    "checkout.address": "Địa Chỉ",
    "checkout.city": "Thành Phố",
    "checkout.zipCode": "Mã Bưu Điện",
    "checkout.paymentMethod": "Phương Thức Thanh Toán",
    "checkout.completePayment": "Hoàn Tất Thanh Toán",
    "checkout.processing": "Đang Xử Lý...",
    
    // Auth
    "auth.login": "Đăng Nhập",
    "auth.register": "Đăng Ký",
    "auth.createAccount": "Tạo Tài Khoản",
    "auth.alreadyHaveAccount": "Đã có tài khoản?",
    "auth.dontHaveAccount": "Chưa có tài khoản?",
    "auth.loginHere": "Đăng nhập tại đây",
    "auth.registerHere": "Đăng ký tại đây",
    "auth.password": "Mật Khẩu",
    "auth.name": "Họ Và Tên",
    "auth.age": "Tuổi",
    "auth.occupation": "Nghề Nghiệp",
    "auth.preferences": "Sở Thích Sản Phẩm (Chọn sở thích của bạn)",
    
    // Login/Register Page
    "auth.email": "Email",
    "auth.invalidCredentials": "Email hoặc mật khẩu không đúng",
    "auth.demoAccounts": "Tài Khoản Demo:",
    "auth.adminAccount": "Admin: admin@beaute.com / admin123",
    "auth.orRegister": "Hoặc đăng ký tài khoản của bạn",
    "auth.loginButton": "Đăng Nhập",
    "auth.or": "Hoặc",
    "auth.loginWithGoogle": "Đăng nhập bằng Google",
    "auth.registerButton": "Đăng Ký",
    "auth.confirmPassword": "Xác Nhận Mật Khẩu",
    "auth.passwordMismatch": "Mật khẩu không khớp",
    "auth.emailExists": "Email đã tồn tại",
    "auth.registrationSuccess": "Đăng ký thành công! Đang chuyển đến trang đăng nhập...",
    "auth.phone": "Số điện thoại",
    "auth.address": "Địa chỉ",
    "auth.required": "*",
    
    // Common
    "common.loading": "Đang tải...",
    "common.search": "Tìm kiếm",
    "common.filter": "Lọc",
    "common.sort": "Sắp xếp",
    "common.price": "Giá",
    "common.color": "Màu sắc",
    "common.size": "Kích thước",
    "common.quantity": "Số lượng",
    "common.inStock": "Còn hàng",
    "common.outOfStock": "Hết hàng",
    "common.clearFilters": "Xóa Lọc",
    "common.all": "Tất cả",
    "common.category": "Danh mục",
    "common.priceRange": "Khoảng giá",
    "common.material": "Chất liệu / Đặc điểm",
    "common.viewDetails": "Xem chi tiết",
    "common.addToWishlist": "Thêm vào danh sách yêu thích",
    "common.removeFromWishlist": "Xóa khỏi danh sách yêu thích",
    "common.buyNow": "Mua ngay",
    "common.showing": "Hiển thị",
    "common.products": "sản phẩm",
    "common.noProducts": "Không tìm thấy sản phẩm",
    "common.tryDifferentFilters": "Vui lòng thử các bộ lọc khác",
    
    // Toast messages
    "toast.addedToWishlist": "Đã thêm vào danh sách yêu thích",
    "toast.removedFromWishlist": "Đã xóa khỏi danh sách yêu thích",
    "toast.addedToCart": "Đã thêm vào giỏ hàng",
    
    // Sort options
    "sort.featured": "Nổi bật",
    "sort.priceLowHigh": "Giá: Thấp đến Cao",
    "sort.priceHighLow": "Giá: Cao đến Thấp",
    "sort.nameAZ": "Tên: A-Z",
    "sort.nameZA": "Tên: Z-A",
    "sort.rating": "Đánh giá cao nhất",
  },
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("vi");

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  const formatPrice = (price: number): string => {
    if (language === "en") {
      return `$${price.toFixed(2)}`;
    } else {
      return `${(price * USD_TO_VND).toLocaleString("vi-VN")} ₫`;
    }
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, formatPrice }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within LanguageProvider");
  }
  return context;
}