import { createContext, useContext, useEffect, ReactNode } from "react";
import { useLocation } from "react-router-dom";

interface AnalyticsContextType {
  trackPageView: (page: string) => void;
  trackEvent: (eventName: string, data?: any) => void;
  trackProductView: (productId: number, productName: string) => void;
  trackTimeOnPage: (page: string, seconds: number) => void;
}

const AnalyticsContext = createContext<AnalyticsContextType | undefined>(undefined);

export function AnalyticsProvider({ children }: { children: ReactNode }) {
  const location = useLocation();
  let pageStartTime = Date.now();

  useEffect(() => {
    pageStartTime = Date.now();
    trackPageView(location.pathname);

    return () => {
      const timeSpent = (Date.now() - pageStartTime) / 1000;
      trackTimeOnPage(location.pathname, timeSpent);
    };
  }, [location]);

  const trackPageView = (page: string) => {
    const events = JSON.parse(localStorage.getItem("analytics_events") || "[]");
    events.push({
      event: "page_view",
      page,
      timestamp: new Date().toISOString(),
      sessionId: getSessionId(),
    });
    localStorage.setItem("analytics_events", JSON.stringify(events));
  };

  const trackEvent = (eventName: string, data?: any) => {
    const events = JSON.parse(localStorage.getItem("analytics_events") || "[]");
    events.push({
      event: eventName,
      data,
      timestamp: new Date().toISOString(),
      sessionId: getSessionId(),
    });
    localStorage.setItem("analytics_events", JSON.stringify(events));
  };

  const trackProductView = (productId: number, productName: string) => {
    trackEvent("product_view", { productId, productName });
    
    // Update most viewed products
    const viewedProducts = JSON.parse(localStorage.getItem("viewed_products") || "{}");
    viewedProducts[productId] = (viewedProducts[productId] || 0) + 1;
    localStorage.setItem("viewed_products", JSON.stringify(viewedProducts));
  };

  const trackTimeOnPage = (page: string, seconds: number) => {
    const events = JSON.parse(localStorage.getItem("analytics_events") || "[]");
    events.push({
      event: "time_on_page",
      page,
      seconds,
      timestamp: new Date().toISOString(),
      sessionId: getSessionId(),
    });
    localStorage.setItem("analytics_events", JSON.stringify(events));
  };

  return (
    <AnalyticsContext.Provider
      value={{
        trackPageView,
        trackEvent,
        trackProductView,
        trackTimeOnPage,
      }}
    >
      {children}
    </AnalyticsContext.Provider>
  );
}

export function useAnalytics() {
  const context = useContext(AnalyticsContext);
  if (!context) {
    throw new Error("useAnalytics must be used within AnalyticsProvider");
  }
  return context;
}

function getSessionId() {
  let sessionId = sessionStorage.getItem("session_id");
  if (!sessionId) {
    sessionId = Date.now().toString() + Math.random().toString(36);
    sessionStorage.setItem("session_id", sessionId);
  }
  return sessionId;
}
