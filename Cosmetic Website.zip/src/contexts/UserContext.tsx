import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface User {
  id: number;
  name: string;
  email: string;
  age?: number;
  address?: string;
  occupation?: string;
  phone?: string;
  preferences?: string[];
}

interface UserContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (userData: Partial<User> & { password: string }) => Promise<boolean>;
  updateProfile: (userData: Partial<User>) => void;
  isAdmin: boolean;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem("current_user");
    return saved ? JSON.parse(saved) : null;
  });

  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    if (user) {
      localStorage.setItem("current_user", JSON.stringify(user));
      setIsAdmin(user.email === "admin@beaute.com");
    } else {
      localStorage.removeItem("current_user");
      setIsAdmin(false);
    }
  }, [user]);

  const login = async (email: string, password: string): Promise<boolean> => {
    // Mock login - in real app, this would call an API
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const foundUser = users.find(
      (u: any) => u.email === email && u.password === password
    );

    if (foundUser || (email === "admin@beaute.com" && password === "admin123")) {
      const userData = foundUser || {
        id: 0,
        name: "Admin",
        email: "admin@beaute.com",
      };
      setUser(userData);
      
      // Track login event
      trackEvent("user_login", { userId: userData.id });
      
      return true;
    }
    return false;
  };

  const logout = () => {
    if (user) {
      trackEvent("user_logout", { userId: user.id });
    }
    setUser(null);
  };

  const register = async (userData: Partial<User> & { password: string }): Promise<boolean> => {
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    
    // Check if email already exists
    if (users.some((u: any) => u.email === userData.email)) {
      return false;
    }

    const newUser: User = {
      id: Date.now(),
      name: userData.name || "",
      email: userData.email || "",
      age: userData.age,
      address: userData.address,
      occupation: userData.occupation,
      phone: userData.phone,
      preferences: userData.preferences,
    };

    users.push({ ...newUser, password: userData.password });
    localStorage.setItem("users", JSON.stringify(users));
    
    setUser(newUser);
    
    // Track registration event
    trackEvent("user_register", { 
      userId: newUser.id, 
      age: newUser.age,
      occupation: newUser.occupation 
    });
    
    return true;
  };

  const updateProfile = (userData: Partial<User>) => {
    if (!user) return;
    
    const updatedUser = { ...user, ...userData };
    setUser(updatedUser);
    
    // Update in users list
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const updatedUsers = users.map((u: any) =>
      u.id === user.id ? { ...u, ...userData } : u
    );
    localStorage.setItem("users", JSON.stringify(updatedUsers));
  };

  return (
    <UserContext.Provider
      value={{
        user,
        login,
        logout,
        register,
        updateProfile,
        isAdmin,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error("useUser must be used within UserProvider");
  }
  return context;
}

function trackEvent(eventName: string, data: any) {
  const events = JSON.parse(localStorage.getItem("analytics_events") || "[]");
  events.push({
    event: eventName,
    data,
    timestamp: new Date().toISOString(),
  });
  localStorage.setItem("analytics_events", JSON.stringify(events));
}
