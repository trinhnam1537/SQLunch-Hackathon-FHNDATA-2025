import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { CartProvider } from "./contexts/CartContext";
import { AnalyticsProvider } from "./contexts/AnalyticsContext";
import { UserProvider } from "./contexts/UserContext";
import { LanguageProvider } from "./contexts/LanguageContext";
import { WishlistProvider } from "./contexts/WishlistContext";
import { OrderProvider } from "./contexts/OrderContext";
import { Chatbot } from "./components/Chatbot";
import { Toaster } from "./components/ui/sonner";

// User Pages
import { HomePage } from "./pages/HomePage";
import { ShopPage } from "./pages/ShopPage";
import { ProductDetailPage } from "./pages/ProductDetailPage";
import { CartPage } from "./pages/CartPage";
import { CheckoutPage } from "./pages/CheckoutPage";
import { BlogPage } from "./pages/BlogPage";
import { RegisterPage } from "./pages/RegisterPage";
import { LoginPage } from "./pages/LoginPage";
import { WishlistPage } from "./pages/WishlistPage";
import { OrderConfirmationPage } from "./pages/OrderConfirmationPage";
import { ProfilePage } from "./pages/ProfilePage";
import { OrderHistoryPage } from "./pages/OrderHistoryPage";

// Admin Pages
import { AdminDashboard } from "./pages/admin/AdminDashboard";
import { AdminProducts } from "./pages/admin/AdminProducts";
import { AdminAnalytics } from "./pages/admin/AdminAnalytics";
import { AdminUsers } from "./pages/admin/AdminUsers";
import { AdminReports } from "./pages/admin/AdminReports";

export default function App() {
  return (
    <Router>
      <LanguageProvider>
        <UserProvider>
          <AnalyticsProvider>
            <WishlistProvider>
              <CartProvider>
                <OrderProvider>
                  <Routes>
                    {/* User Routes */}
                    <Route path="/" element={<HomePage />} />
                    <Route path="/shop" element={<ShopPage />} />
                    <Route path="/product/:id" element={<ProductDetailPage />} />
                    <Route path="/cart" element={<CartPage />} />
                    <Route path="/checkout" element={<CheckoutPage />} />
                    <Route path="/blog" element={<BlogPage />} />
                    <Route path="/register" element={<RegisterPage />} />
                    <Route path="/login" element={<LoginPage />} />
                    <Route path="/wishlist" element={<WishlistPage />} />
                    <Route path="/order-confirmation" element={<OrderConfirmationPage />} />
                    <Route path="/profile" element={<ProfilePage />} />
                    <Route path="/order-history" element={<OrderHistoryPage />} />

                    {/* Admin Routes */}
                    <Route path="/admin" element={<AdminDashboard />} />
                    <Route path="/admin/products" element={<AdminProducts />} />
                    <Route path="/admin/analytics" element={<AdminAnalytics />} />
                    <Route path="/admin/users" element={<AdminUsers />} />
                    <Route path="/admin/reports" element={<AdminReports />} />

                    {/* Catch all route - redirect to home */}
                    <Route path="*" element={<Navigate to="/" replace />} />
                  </Routes>

                  {/* Global Chatbot */}
                  <Chatbot />
                  <Toaster />
                </OrderProvider>
              </CartProvider>
            </WishlistProvider>
          </AnalyticsProvider>
        </UserProvider>
      </LanguageProvider>
    </Router>
  );
}
