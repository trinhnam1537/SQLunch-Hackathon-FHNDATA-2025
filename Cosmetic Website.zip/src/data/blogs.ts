export interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  image: string;
  category: string;
  readTime: number;
}

export const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "10 Skincare Tips for Radiant Skin",
    excerpt: "Discover the secrets to achieving healthy, glowing skin with these expert-approved tips.",
    content: "Full content here...",
    author: "Dr. Sarah Johnson",
    date: "2025-11-15",
    image: "https://images.unsplash.com/photo-1643379850623-7eb6442cd262?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwc2tpbmNhcmUlMjBib3R0bGVzfGVufDF8fHx8MTc2MzMxNjk3MXww&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Skincare",
    readTime: 5,
  },
  {
    id: 2,
    title: "The Ultimate Makeup Guide for Beginners",
    excerpt: "Learn the basics of makeup application with our comprehensive beginner's guide.",
    content: "Full content here...",
    author: "Emma Williams",
    date: "2025-11-12",
    image: "https://images.unsplash.com/photo-1723150512429-bfa92988d845?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWtldXAlMjBwcm9kdWN0cyUyMGJlYXV0eXxlbnwxfHx8fDE3NjMyNzgzMTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Makeup",
    readTime: 8,
  },
  {
    id: 3,
    title: "Finding Your Signature Scent",
    excerpt: "A guide to choosing the perfect fragrance that matches your personality.",
    content: "Full content here...",
    author: "Michael Chen",
    date: "2025-11-10",
    image: "https://images.unsplash.com/photo-1759794108525-94ff060da692?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJmdW1lJTIwYm90dGxlcyUyMGx1eHVyeXxlbnwxfHx8fDE3NjMzMzY2ODd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    category: "Fragrance",
    readTime: 6,
  },
];
