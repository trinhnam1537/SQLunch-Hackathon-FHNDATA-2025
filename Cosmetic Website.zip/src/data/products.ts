export interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  image: string;
  description: string;
  colors?: string[];
  sizes?: string[];
  material?: string;
  stock: number;
  tags: string[];
}

export const products: Product[] = [
  {
    id: 1,
    name: "Radiance Vitamin C Serum",
    category: "Skincare",
    price: 89.99,
    originalPrice: 119.99,
    rating: 4.8,
    reviews: 234,
    image: "https://images.unsplash.com/photo-1643379850623-7eb6442cd262?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwc2tpbmNhcmUlMjBib3R0bGVzfGVufDF8fHx8MTc2MzMxNjk3MXww&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Brightening serum with 20% Vitamin C for radiant, youthful skin",
    colors: ["Clear"],
    sizes: ["30ml", "50ml"],
    material: "Glass bottle",
    stock: 45,
    tags: ["brightening", "anti-aging", "vitamin-c"],
  },
  {
    id: 2,
    name: "Velvet Matte Lipstick - Ruby Red",
    category: "Makeup",
    price: 34.99,
    rating: 4.9,
    reviews: 456,
    image: "https://images.unsplash.com/photo-1625093742435-6fa192b6fb10?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsaXBzdGljayUyMG1ha2V1cHxlbnwxfHx8fDE3NjMyNjUyNDV8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Long-lasting matte lipstick with rich, vibrant color",
    colors: ["Ruby Red", "Rose Pink", "Berry Wine", "Nude Beige"],
    material: "Vegan formula",
    stock: 120,
    tags: ["long-lasting", "matte", "vegan"],
  },
  {
    id: 3,
    name: "Luxury Eau de Parfum - Rose Garden",
    category: "Fragrance",
    price: 149.99,
    rating: 4.7,
    reviews: 189,
    image: "https://images.unsplash.com/photo-1759794108525-94ff060da692?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJmdW1lJTIwYm90dGxlcyUyMGx1eHVyeXxlbnwxfHx8fDE3NjMzMzY2ODd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Elegant floral fragrance with notes of rose, jasmine, and sandalwood",
    sizes: ["50ml", "100ml"],
    material: "Crystal bottle",
    stock: 32,
    tags: ["floral", "luxury", "long-lasting"],
  },
  {
    id: 4,
    name: "Hydrating Face Cream",
    category: "Skincare",
    price: 64.99,
    originalPrice: 84.99,
    rating: 4.9,
    reviews: 567,
    image: "https://images.unsplash.com/photo-1667242003558-e42942d2b911?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWNlJTIwY3JlYW0lMjBqYXJ8ZW58MXx8fHwxNzYzMzA2MzkyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "24-hour hydration with hyaluronic acid and natural oils",
    sizes: ["50ml", "100ml"],
    material: "Glass jar",
    stock: 78,
    tags: ["hydrating", "hyaluronic-acid", "natural"],
  },
  {
    id: 5,
    name: "Silk Foundation - Natural Beige",
    category: "Makeup",
    price: 54.99,
    rating: 4.6,
    reviews: 342,
    image: "https://images.unsplash.com/photo-1723150512429-bfa92988d845?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWtldXAlMjBwcm9kdWN0cyUyMGJlYXV0eXxlbnwxfHx8fDE3NjMyNzgzMTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Full coverage foundation with silk-smooth finish",
    colors: ["Porcelain", "Natural Beige", "Warm Tan", "Deep Caramel"],
    sizes: ["30ml"],
    material: "Liquid formula",
    stock: 95,
    tags: ["full-coverage", "long-lasting", "smooth"],
  },
  {
    id: 6,
    name: "Anti-Aging Night Cream",
    category: "Skincare",
    price: 94.99,
    rating: 4.8,
    reviews: 278,
    image: "https://images.unsplash.com/photo-1643379850623-7eb6442cd262?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwc2tpbmNhcmUlMjBib3R0bGVzfGVufDF8fHx8MTc2MzMxNjk3MXww&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Retinol-infused night cream for youthful, radiant skin",
    sizes: ["50ml"],
    material: "Airless pump bottle",
    stock: 56,
    tags: ["anti-aging", "retinol", "night-care"],
  },
  {
    id: 7,
    name: "Volume Mascara - Jet Black",
    category: "Makeup",
    price: 29.99,
    rating: 4.7,
    reviews: 521,
    image: "https://images.unsplash.com/photo-1723150512429-bfa92988d845?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWtldXAlMjBwcm9kdWN0cyUyMGJlYXV0eXxlbnwxfHx8fDE3NjMyNzgzMTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Volumizing mascara for dramatic lashes",
    colors: ["Jet Black", "Brown"],
    material: "Waterproof formula",
    stock: 145,
    tags: ["volume", "waterproof", "long-lasting"],
  },
  {
    id: 8,
    name: "Body Butter - Vanilla Dream",
    category: "Body Care",
    price: 39.99,
    rating: 4.9,
    reviews: 412,
    image: "https://images.unsplash.com/photo-1667242003558-e42942d2b911?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWNlJTIwY3JlYW0lMjBqYXJ8ZW58MXx8fHwxNzYzMzA2MzkyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    description: "Rich, nourishing body butter with shea and cocoa butter",
    sizes: ["200ml", "400ml"],
    material: "Jar",
    stock: 88,
    tags: ["moisturizing", "nourishing", "vanilla"],
  },
];

export const categories = [
  { id: 1, name: "Skincare", count: 156 },
  { id: 2, name: "Makeup", count: 234 },
  { id: 3, name: "Fragrance", count: 89 },
  { id: 4, name: "Body Care", count: 127 },
  { id: 5, name: "Hair Care", count: 98 },
];
