import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { AdminLayout } from "../../components/admin/AdminLayout";
import { Card } from "../../components/ui/card";
import { useUser } from "../../contexts/UserContext";
import { useAnalytics } from "../../contexts/AnalyticsContext";
import { useLanguage } from "../../contexts/LanguageContext";
import {
  Users,
  ShoppingBag,
  DollarSign,
  TrendingUp,
  Package,
  Eye,
} from "lucide-react";

export function AdminDashboard() {
  const { user, isAdmin } = useUser();
  const { getAnalyticsSummary } = useAnalytics();
  const { formatPrice } = useLanguage();
  const navigate = useNavigate();
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalOrders: 0,
    totalRevenue: 0,
    totalPageViews: 0,
    addToCartRate: 0,
    conversionRate: 0,
    averageSessionTime: 0,
    returningUsers: 0,
  });

  useEffect(() => {
    if (!user || !isAdmin) {
      navigate("/login");
      return;
    }

    // Calculate stats from analytics
    const analyticsSummary = getAnalyticsSummary();

    setStats({
      totalUsers: analyticsSummary.totalUsers,
      totalOrders: analyticsSummary.totalOrders,
      totalRevenue: analyticsSummary.totalRevenue,
      totalPageViews: analyticsSummary.totalPageViews,
      addToCartRate: analyticsSummary.addToCartRate,
      conversionRate: analyticsSummary.conversionRate,
      averageSessionTime: analyticsSummary.averageSessionTime,
      returningUsers: analyticsSummary.returningUsers,
    });
  }, [user, isAdmin, navigate, getAnalyticsSummary]);

  const statCards = [
    {
      title: "Total Users",
      value: stats.totalUsers,
      icon: Users,
      color: "text-[#2B6377]",
      bg: "bg-[#CCDFE3]",
    },
    {
      title: "Total Orders",
      value: stats.totalOrders,
      icon: ShoppingBag,
      color: "text-[#2B6377]",
      bg: "bg-[#CCDFE3]",
    },
    {
      title: "Total Revenue",
      value: formatPrice(stats.totalRevenue),
      icon: DollarSign,
      color: "text-[#2B6377]",
      bg: "bg-[#CCDFE3]",
    },
    {
      title: "Page Views",
      value: stats.totalPageViews,
      icon: Eye,
      color: "text-[#2B6377]",
      bg: "bg-[#CCDFE3]",
    },
    {
      title: "Add to Cart Rate",
      value: `${stats.addToCartRate.toFixed(1)}%`,
      icon: TrendingUp,
      color: "text-[#2B6377]",
      bg: "bg-[#CCDFE3]",
    },
    {
      title: "Conversion Rate",
      value: `${stats.conversionRate.toFixed(1)}%`,
      icon: Package,
      color: "text-[#2B6377]",
      bg: "bg-[#CCDFE3]",
    },
  ];

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-4xl mb-2">Dashboard Overview</h1>
        <p className="text-gray-600">Real-time analytics and performance metrics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600 mb-1">{stat.title}</p>
                  <p className="text-3xl">{stat.value}</p>
                </div>
                <div className={`${stat.bg} ${stat.color} p-4 rounded-full`}>
                  <Icon className="h-6 w-6" />
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h2 className="text-2xl mb-4">User Engagement</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Average Session Time</span>
              <span className="text-xl">{stats.averageSessionTime.toFixed(0)}s</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Returning Users</span>
              <span className="text-xl">{stats.returningUsers}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Sessions with 5s+ engagement</span>
              <span className="text-xl">
                {stats.averageSessionTime >= 5 ? "✓" : "✗"}
              </span>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-2xl mb-4">Quick Actions</h2>
          <div className="space-y-3">
            <Link to="/admin/analytics">
              <div className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                View Detailed Analytics →
              </div>
            </Link>
            <Link to="/admin/reports">
              <div className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                Generate Reports →
              </div>
            </Link>
            <Link to="/admin/users">
              <div className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                Manage Users →
              </div>
            </Link>
            <Link to="/admin/products">
              <div className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                Manage Products →
              </div>
            </Link>
          </div>
        </Card>
      </div>
    </AdminLayout>
  );
}