import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AdminLayout } from "../../components/admin/AdminLayout";
import { Card } from "../../components/ui/card";
import { useUser } from "../../contexts/UserContext";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const COLORS = ["#ec4899", "#8b5cf6", "#3b82f6", "#10b981", "#f59e0b"];

export function AdminAnalytics() {
  const { user, isAdmin } = useUser();
  const navigate = useNavigate();
  const [mostViewedProducts, setMostViewedProducts] = useState<any[]>([]);
  const [categoryData, setCategoryData] = useState<any[]>([]);
  const [timelineData, setTimelineData] = useState<any[]>([]);
  const [userBehavior, setUserBehavior] = useState<any>({});

  useEffect(() => {
    if (!user || !isAdmin) {
      navigate("/login");
      return;
    }

    // Get most viewed products
    const viewedProducts = JSON.parse(
      localStorage.getItem("viewed_products") || "{}"
    );
    const productViews = Object.entries(viewedProducts)
      .map(([id, views]) => ({
        productId: id,
        views: views as number,
      }))
      .sort((a, b) => b.views - a.views)
      .slice(0, 5);
    setMostViewedProducts(productViews);

    // Simulate category performance data
    setCategoryData([
      { name: "Skincare", views: 245, sales: 89 },
      { name: "Makeup", views: 312, sales: 156 },
      { name: "Fragrance", views: 178, sales: 67 },
      { name: "Body Care", views: 198, sales: 92 },
    ]);

    // Simulate timeline data
    setTimelineData([
      { date: "Mon", users: 45, orders: 12 },
      { date: "Tue", users: 52, orders: 18 },
      { date: "Wed", users: 61, orders: 15 },
      { date: "Thu", users: 48, orders: 22 },
      { date: "Fri", users: 73, orders: 28 },
      { date: "Sat", users: 95, orders: 41 },
      { date: "Sun", users: 88, orders: 35 },
    ]);

    // Analyze user behavior
    const events = JSON.parse(localStorage.getItem("analytics_events") || "[]");
    const sessions = {};
    
    events.forEach((event: any) => {
      if (!sessions[event.sessionId]) {
        sessions[event.sessionId] = {
          events: [],
          duration: 0,
        };
      }
      sessions[event.sessionId].events.push(event);
    });

    const totalSessions = Object.keys(sessions).length;
    const sessionsOver5s = Object.values(sessions).filter((s: any) => {
      const timeEvents = s.events.filter((e: any) => e.event === "time_on_page");
      const totalTime = timeEvents.reduce((sum: number, e: any) => sum + (e.seconds || 0), 0);
      return totalTime >= 5;
    }).length;

    setUserBehavior({
      totalSessions,
      engagedSessions: sessionsOver5s,
      engagementRate: totalSessions > 0 ? (sessionsOver5s / totalSessions) * 100 : 0,
    });
  }, [user, isAdmin, navigate]);

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-4xl mb-2">Analytics Dashboard</h1>
        <p className="text-gray-600">Detailed insights into user behavior and sales performance</p>
      </div>

      {/* User Engagement */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card className="p-6">
          <h3 className="mb-2 text-gray-600">Total Sessions</h3>
          <p className="text-3xl">{userBehavior.totalSessions || 0}</p>
        </Card>
        <Card className="p-6">
          <h3 className="mb-2 text-gray-600">Engaged Sessions (5s+)</h3>
          <p className="text-3xl">{userBehavior.engagedSessions || 0}</p>
        </Card>
        <Card className="p-6">
          <h3 className="mb-2 text-gray-600">Engagement Rate</h3>
          <p className="text-3xl">{userBehavior.engagementRate?.toFixed(1) || 0}%</p>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Category Performance */}
        <Card className="p-6">
          <h2 className="text-2xl mb-6">Category Performance</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={categoryData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="views" fill="#ec4899" name="Views" />
              <Bar dataKey="sales" fill="#8b5cf6" name="Sales" />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        {/* Weekly Trend */}
        <Card className="p-6">
          <h2 className="text-2xl mb-6">Weekly Trend</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={timelineData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="users" stroke="#3b82f6" name="Users" />
              <Line type="monotone" dataKey="orders" stroke="#10b981" name="Orders" />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Most Viewed Products */}
      <Card className="p-6 mb-8">
        <h2 className="text-2xl mb-6">Most Viewed Products</h2>
        {mostViewedProducts.length > 0 ? (
          <div className="space-y-4">
            {mostViewedProducts.map((product, index) => (
              <div
                key={product.productId}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center gap-4">
                  <span className="text-2xl text-gray-400">#{index + 1}</span>
                  <div>
                    <p>Product ID: {product.productId}</p>
                    <p className="text-sm text-gray-600">{product.views} views</p>
                  </div>
                </div>
                <div className="w-48 bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-pink-600 h-2 rounded-full"
                    style={{
                      width: `${(product.views / Math.max(...mostViewedProducts.map((p) => p.views))) * 100}%`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-600 text-center py-8">
            No product views tracked yet. Start browsing products to see analytics.
          </p>
        )}
      </Card>

      {/* Marketing Recommendations */}
      <Card className="p-6">
        <h2 className="text-2xl mb-6">AI Marketing Recommendations</h2>
        <div className="space-y-4">
          <div className="p-4 bg-blue-50 border-l-4 border-blue-600 rounded">
            <h3 className="mb-2">🎯 Top Performing Category</h3>
            <p className="text-gray-700">
              Makeup category has the highest conversion rate. Consider running a
              promotional campaign to boost sales further.
            </p>
          </div>
          <div className="p-4 bg-green-50 border-l-4 border-green-600 rounded">
            <h3 className="mb-2">💡 Cross-sell Opportunity</h3>
            <p className="text-gray-700">
              Users viewing skincare products often add fragrances to cart. Create
              bundle deals for better conversion.
            </p>
          </div>
          <div className="p-4 bg-purple-50 border-l-4 border-purple-600 rounded">
            <h3 className="mb-2">📈 Inventory Alert</h3>
            <p className="text-gray-700">
              Products with high view counts but low stock should be restocked to
              avoid lost sales opportunities.
            </p>
          </div>
        </div>
      </Card>
    </AdminLayout>
  );
}
