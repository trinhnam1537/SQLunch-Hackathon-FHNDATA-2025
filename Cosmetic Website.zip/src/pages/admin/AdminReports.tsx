import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AdminLayout } from "../../components/admin/AdminLayout";
import { Card } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { useUser } from "../../contexts/UserContext";
import { useAnalytics } from "../../contexts/AnalyticsContext";
import { useLanguage } from "../../contexts/LanguageContext";
import { Download, FileText, Calendar } from "lucide-react";

type ReportPeriod = "today" | "week" | "month" | "year";

export function AdminReports() {
  const { user, isAdmin } = useUser();
  const { getAnalyticsSummary } = useAnalytics();
  const { formatPrice } = useLanguage();
  const navigate = useNavigate();
  const [period, setPeriod] = useState<ReportPeriod>("month");
  const [reportData, setReportData] = useState<any>(null);

  useEffect(() => {
    if (!user || !isAdmin) {
      navigate("/login");
      return;
    }

    generateReport(period);
  }, [user, isAdmin, navigate, period]);

  const generateReport = (period: ReportPeriod) => {
    const events = JSON.parse(localStorage.getItem("analytics_events") || "[]");
    const users = JSON.parse(localStorage.getItem("users") || "[]");

    // Filter events based on period
    const now = new Date();
    const filterDate = new Date();
    
    if (period === "today") {
      filterDate.setDate(now.getDate() - 1);
    } else if (period === "week") {
      filterDate.setDate(now.getDate() - 7);
    } else if (period === "month") {
      filterDate.setMonth(now.getMonth() - 1);
    } else if (period === "year") {
      filterDate.setFullYear(now.getFullYear() - 1);
    }

    const filteredEvents = events.filter((e: any) => {
      return new Date(e.timestamp) >= filterDate;
    });

    // Calculate metrics
    const pageViews = filteredEvents.filter((e: any) => e.event === "page_view").length;
    const productViews = filteredEvents.filter((e: any) => e.event === "product_view").length;
    const addToCarts = filteredEvents.filter((e: any) => e.event === "add_to_cart").length;
    const payments = filteredEvents.filter((e: any) => e.event === "payment_success").length;
    const newUsers = filteredEvents.filter((e: any) => e.event === "user_register").length;

    const totalRevenue = filteredEvents
      .filter((e: any) => e.event === "payment_success")
      .reduce((sum: number, e: any) => sum + (e.data?.amount || 0), 0);

    const uniqueSessions = new Set(filteredEvents.map((e: any) => e.sessionId)).size;
    
    setReportData({
      period,
      periodLabel: period.charAt(0).toUpperCase() + period.slice(1),
      metrics: {
        pageViews,
        productViews,
        addToCarts,
        payments,
        newUsers,
        totalRevenue,
        uniqueSessions,
        conversionRate: addToCarts > 0 ? (payments / addToCarts) * 100 : 0,
        addToCartRate: pageViews > 0 ? (addToCarts / pageViews) * 100 : 0,
        averageOrderValue: payments > 0 ? totalRevenue / payments : 0,
      },
    });
  };

  const downloadReport = () => {
    if (!reportData) return;

    const reportText = `
BEAUTÉ E-COMMERCE ${reportData.periodLabel.toUpperCase()} REPORT
Generated: ${new Date().toLocaleString()}
================================================

KEY METRICS
-----------
Total Page Views: ${reportData.metrics.pageViews}
Product Views: ${reportData.metrics.productViews}
Add to Carts: ${reportData.metrics.addToCarts}
Completed Orders: ${reportData.metrics.payments}
New Users: ${reportData.metrics.newUsers}
Unique Sessions: ${reportData.metrics.uniqueSessions}

REVENUE
-------
Total Revenue: ${formatPrice(reportData.metrics.totalRevenue)}
Average Order Value: ${formatPrice(reportData.metrics.averageOrderValue)}

CONVERSION METRICS
------------------
Add to Cart Rate: ${reportData.metrics.addToCartRate.toFixed(2)}%
Conversion Rate: ${reportData.metrics.conversionRate.toFixed(2)}%

RECOMMENDATIONS
---------------
${reportData.metrics.conversionRate < 5 
  ? "- Low conversion rate. Consider improving product descriptions and images."
  : "- Good conversion rate. Continue current strategies."}
${reportData.metrics.addToCartRate < 10
  ? "- Low add-to-cart rate. Optimize product presentation and pricing."
  : "- Healthy add-to-cart rate."}
${reportData.metrics.payments > 0
  ? "- Sales are happening! Focus on customer retention."
  : "- No sales yet. Consider promotional campaigns."}
    `;

    const blob = new Blob([reportText], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `beaute-report-${reportData.period}-${new Date().toISOString().split('T')[0]}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (!reportData) return null;

  return (
    <AdminLayout>
      <div className="mb-8 flex justify-between items-start">
        <div>
          <h1 className="text-4xl mb-2">Reports & Analytics</h1>
          <p className="text-gray-600">Generate and download comprehensive business reports</p>
        </div>
        <Button
          onClick={downloadReport}
          className="bg-[#2B6377] hover:bg-[#2B6377]/90 text-white"
        >
          <Download className="mr-2 h-4 w-4" />
          Download Report
        </Button>
      </div>

      {/* Time Period Selection */}
      <div className="flex gap-3 mb-8">
        <Button
          variant={period === "today" ? "default" : "outline"}
          onClick={() => setPeriod("today")}
          className={period === "today" ? "bg-[#2B6377]" : ""}
        >
          <Calendar className="mr-2 h-4 w-4" />
          Daily
        </Button>

        <Button
          variant={period === "week" ? "default" : "outline"}
          onClick={() => setPeriod("week")}
          className={period === "week" ? "bg-[#2B6377]" : ""}
        >
          <Calendar className="mr-2 h-4 w-4" />
          Weekly
        </Button>

        <Button
          variant={period === "month" ? "default" : "outline"}
          onClick={() => setPeriod("month")}
          className={period === "month" ? "bg-[#2B6377]" : ""}
        >
          <Calendar className="mr-2 h-4 w-4" />
          Monthly
        </Button>

        <Button
          variant={period === "year" ? "default" : "outline"}
          onClick={() => setPeriod("year")}
          className={period === "year" ? "bg-[#2B6377]" : ""}
        >
          <Calendar className="mr-2 h-4 w-4" />
          Yearly
        </Button>
      </div>

      {/* Report Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="p-6">
          <p className="text-sm text-gray-600 mb-1">Page Views</p>
          <p className="text-3xl">{reportData.metrics.pageViews}</p>
        </Card>
        <Card className="p-6">
          <p className="text-sm text-gray-600 mb-1">Product Views</p>
          <p className="text-3xl">{reportData.metrics.productViews}</p>
        </Card>
        <Card className="p-6">
          <p className="text-sm text-gray-600 mb-1">Add to Carts</p>
          <p className="text-3xl">{reportData.metrics.addToCarts}</p>
        </Card>
        <Card className="p-6">
          <p className="text-sm text-gray-600 mb-1">Orders</p>
          <p className="text-3xl">{reportData.metrics.payments}</p>
        </Card>
      </div>

      {/* Revenue & Conversion */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card className="p-6">
          <h2 className="text-2xl mb-6">Revenue Metrics</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Total Revenue</span>
              <span className="text-2xl">{formatPrice(reportData.metrics.totalRevenue)}</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Average Order Value</span>
              <span className="text-2xl">{formatPrice(reportData.metrics.averageOrderValue)}</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Total Orders</span>
              <span className="text-2xl">{reportData.metrics.payments}</span>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="text-2xl mb-6">Conversion Metrics</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Add to Cart Rate</span>
              <span className="text-2xl">{reportData.metrics.addToCartRate.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
              <span className="text-gray-600">Conversion Rate</span>
              <span className="text-2xl">{reportData.metrics.conversionRate.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
              <span className="text-gray-600">New Users</span>
              <span className="text-2xl">{reportData.metrics.newUsers}</span>
            </div>
          </div>
        </Card>
      </div>

      {/* Recommendations */}
      <Card className="p-6">
        <h2 className="text-2xl mb-6">Strategic Recommendations</h2>
        <div className="space-y-4">
          {reportData.metrics.conversionRate < 5 && (
            <div className="p-4 bg-yellow-50 border-l-4 border-yellow-600 rounded">
              <h3 className="mb-2">⚠️ Low Conversion Rate</h3>
              <p className="text-gray-700">
                The conversion rate is below industry standard (5%). Consider:
                <ul className="list-disc ml-6 mt-2">
                  <li>Improving product descriptions and images</li>
                  <li>Offering limited-time promotions</li>
                  <li>Simplifying the checkout process</li>
                </ul>
              </p>
            </div>
          )}
          
          {reportData.metrics.addToCartRate < 10 && (
            <div className="p-4 bg-orange-50 border-l-4 border-orange-600 rounded">
              <h3 className="mb-2">📊 Low Add-to-Cart Rate</h3>
              <p className="text-gray-700">
                Users are viewing but not adding to cart. Consider:
                <ul className="list-disc ml-6 mt-2">
                  <li>Reviewing pricing strategy</li>
                  <li>Adding more product reviews</li>
                  <li>Highlighting unique selling points</li>
                </ul>
              </p>
            </div>
          )}

          {reportData.metrics.payments === 0 && (
            <div className="p-4 bg-red-50 border-l-4 border-red-600 rounded">
              <h3 className="mb-2">🎯 No Sales Yet</h3>
              <p className="text-gray-700">
                Focus on generating first sales:
                <ul className="list-disc ml-6 mt-2">
                  <li>Launch a promotional campaign</li>
                  <li>Offer first-time buyer discount</li>
                  <li>Improve trust signals (reviews, guarantees)</li>
                </ul>
              </p>
            </div>
          )}

          {reportData.metrics.conversionRate >= 5 && reportData.metrics.payments > 0 && (
            <div className="p-4 bg-green-50 border-l-4 border-green-600 rounded">
              <h3 className="mb-2">✅ Strong Performance</h3>
              <p className="text-gray-700">
                Great job! Your conversion metrics are healthy. Focus on:
                <ul className="list-disc ml-6 mt-2">
                  <li>Customer retention programs</li>
                  <li>Upselling and cross-selling strategies</li>
                  <li>Building brand loyalty</li>
                </ul>
              </p>
            </div>
          )}
        </div>
      </Card>
    </AdminLayout>
  );
}