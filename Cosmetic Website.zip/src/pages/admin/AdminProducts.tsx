import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AdminLayout } from "../../components/admin/AdminLayout";
import { Card } from "../../components/ui/card";
import { Badge } from "../../components/ui/badge";
import { ImageWithFallback } from "../../components/figma/ImageWithFallback";
import { useUser } from "../../contexts/UserContext";
import { useLanguage } from "../../contexts/LanguageContext";
import { products } from "../../data/products";
import { Package, TrendingUp, AlertCircle } from "lucide-react";

export function AdminProducts() {
  const { user, isAdmin } = useUser();
  const { formatPrice } = useLanguage();
  const navigate = useNavigate();
  const [viewedProducts, setViewedProducts] = useState<any>({});

  useEffect(() => {
    if (!user || !isAdmin) {
      navigate("/login");
      return;
    }

    const viewed = JSON.parse(localStorage.getItem("viewed_products") || "{}");
    setViewedProducts(viewed);
  }, [user, isAdmin, navigate]);

  const productsWithViews = products.map((product) => ({
    ...product,
    views: viewedProducts[product.id] || 0,
  })).sort((a, b) => b.views - a.views);

  return (
    <AdminLayout>
      <div className="mb-8">
        <h1 className="text-4xl mb-2">Product Management</h1>
        <p className="text-gray-600">Manage products and view performance metrics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="bg-blue-50 p-4 rounded-full">
              <Package className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Products</p>
              <p className="text-3xl">{products.length}</p>
            </div>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="bg-green-50 p-4 rounded-full">
              <TrendingUp className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Most Viewed</p>
              <p className="text-xl">
                {productsWithViews[0]?.name.substring(0, 20)}...
              </p>
            </div>
          </div>
        </Card>
        <Card className="p-6">
          <div className="flex items-center gap-4">
            <div className="bg-orange-50 p-4 rounded-full">
              <AlertCircle className="h-6 w-6 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Low Stock Items</p>
              <p className="text-3xl">
                {products.filter((p) => p.stock < 50).length}
              </p>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <h2 className="text-2xl mb-6">All Products</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b">
              <tr className="text-left">
                <th className="pb-3">Product</th>
                <th className="pb-3">Category</th>
                <th className="pb-3">Price</th>
                <th className="pb-3">Stock</th>
                <th className="pb-3">Views</th>
                <th className="pb-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {productsWithViews.map((product) => (
                <tr key={product.id} className="border-b">
                  <td className="py-4">
                    <div className="flex items-center gap-3">
                      <ImageWithFallback
                        src={product.image}
                        alt={product.name}
                        className="w-12 h-12 object-cover rounded"
                      />
                      <div>
                        <p>{product.name}</p>
                        <p className="text-sm text-gray-600">ID: {product.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4">
                    <Badge variant="outline">{product.category}</Badge>
                  </td>
                  <td className="py-4">{formatPrice(product.price)}</td>
                  <td className="py-4">
                    <span
                      className={
                        product.stock < 20
                          ? "text-red-600"
                          : product.stock < 50
                          ? "text-orange-600"
                          : "text-green-600"
                      }
                    >
                      {product.stock}
                    </span>
                  </td>
                  <td className="py-4">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-gray-400" />
                      {product.views}
                    </div>
                  </td>
                  <td className="py-4">
                    {product.stock > 0 ? (
                      <Badge className="bg-green-600">In Stock</Badge>
                    ) : (
                      <Badge className="bg-red-600">Out of Stock</Badge>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </AdminLayout>
  );
}