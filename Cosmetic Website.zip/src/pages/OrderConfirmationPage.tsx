import { useEffect } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { Navbar } from "../components/Navbar";
import { Footer } from "../components/Footer";
import { Button } from "../components/ui/button";
import { useLanguage } from "../contexts/LanguageContext";
import { useUser } from "../contexts/UserContext";
import { useOrder } from "../contexts/OrderContext";
import { 
  CheckCircle, 
  Package, 
  Truck, 
  MapPin, 
  Clock, 
  Phone, 
  Mail,
  Copy,
  ExternalLink 
} from "lucide-react";
import { toast } from "sonner@2.0.3";

export function OrderConfirmationPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { formatPrice } = useLanguage();
  const { user } = useUser();
  const { addOrder } = useOrder();
  const orderData = location.state;

  useEffect(() => {
    if (!orderData) {
      navigate("/");
      return;
    }

    // Generate tracking info
    const trackingNumber = `VTP${Math.floor(Math.random() * 10000000000).toString().padStart(10, '0')}`;
    const orderNumber = `ORD${Date.now().toString().slice(-8)}`;
    const estimatedDelivery = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString();

    // Save order to OrderContext - use userId 0 for guest users
    addOrder({
      orderNumber,
      trackingNumber,
      userId: user?.id || 0,
      items: orderData.items,
      subtotal: orderData.subtotal,
      discount: orderData.discount,
      shipping: orderData.shipping,
      tax: orderData.tax,
      total: orderData.total,
      paymentMethod: orderData.paymentMethod,
      coupon: orderData.coupon,
      shippingInfo: orderData.shippingInfo,
      status: "processing",
      estimatedDelivery,
    });

    // Store in location state for display
    location.state = {
      ...orderData,
      trackingNumber,
      orderNumber,
      estimatedDelivery,
    };
  }, []);

  if (!orderData) {
    return null;
  }

  // Generate random Viettel Post tracking number (format: VTP followed by 10 digits)
  const trackingNumber = orderData.trackingNumber || `VTP${Math.floor(Math.random() * 10000000000).toString().padStart(10, '0')}`;
  const orderNumber = orderData.orderNumber || `ORD${Date.now().toString().slice(-8)}`;
  const estimatedDelivery = orderData.estimatedDelivery ? new Date(orderData.estimatedDelivery).toLocaleDateString('vi-VN') : new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toLocaleDateString('vi-VN');

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Đã sao chép mã vận đơn!");
  };

  const openViettelPostTracking = () => {
    // Viettel Post tracking URL (this is a placeholder - real URL would be https://viettelpost.com.vn/tra-cuu-hanh-trinh-don/)
    window.open(`https://viettelpost.com.vn/tra-cuu-hanh-trinh-don/?code=${trackingNumber}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Success Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="h-12 w-12 text-green-600" />
            </div>
          </div>
          <h1 className="text-4xl mb-2">Đặt hàng thành công!</h1>
          <p className="text-gray-600">
            Cảm ơn bạn đã đặt hàng. Đơn hàng của bạn đang được xử lý.
          </p>
        </div>

        {/* Order & Tracking Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Order Number Card */}
          <div className="border rounded-lg p-6 bg-[#FAF6F1]">
            <div className="flex items-center gap-3 mb-4">
              <Package className="h-6 w-6 text-[#2B6377]" />
              <h2 className="text-2xl">Mã đơn hàng</h2>
            </div>
            <p className="text-2xl mb-2">{orderNumber}</p>
            <p className="text-sm text-gray-600">
              Ngày đặt: {new Date().toLocaleDateString('vi-VN')}
            </p>
          </div>

          {/* Viettel Post Tracking Card */}
          <div className="border rounded-lg p-6 bg-[#CCDFE3]">
            <div className="flex items-center gap-3 mb-4">
              <Truck className="h-6 w-6 text-[#2B6377]" />
              <h2 className="text-2xl">Mã vận đơn Viettel Post</h2>
            </div>
            <div className="flex items-center gap-2 mb-3">
              <p className="text-2xl">{trackingNumber}</p>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => copyToClipboard(trackingNumber)}
                className="hover:bg-white/50"
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <Button
              onClick={openViettelPostTracking}
              className="w-full bg-[#2B6377] hover:bg-[#2B6377]/90 text-white flex items-center justify-center gap-2"
            >
              <ExternalLink className="h-4 w-4" />
              Tra cứu vận đơn
            </Button>
          </div>
        </div>

        {/* Delivery Information */}
        <div className="border rounded-lg p-6 mb-8">
          <h2 className="text-2xl mb-6">Thông tin giao hàng</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-gray-600 mt-1" />
                <div>
                  <p className="text-sm text-gray-600 mb-1">Địa chỉ giao hàng</p>
                  <p>{orderData.shippingInfo.fullName}</p>
                  <p>{orderData.shippingInfo.address}</p>
                  <p>{orderData.shippingInfo.city} {orderData.shippingInfo.zipCode}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-gray-600 mt-1" />
                <div>
                  <p className="text-sm text-gray-600 mb-1">Thời gian giao hàng dự kiến</p>
                  <p>{estimatedDelivery}</p>
                  <p className="text-sm text-gray-500">Thường 2-3 ngày làm việc</p>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Phone className="h-5 w-5 text-gray-600 mt-1" />
                <div>
                  <p className="text-sm text-gray-600 mb-1">Số điện thoại</p>
                  <p>{orderData.shippingInfo.phone}</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-gray-600 mt-1" />
                <div>
                  <p className="text-sm text-gray-600 mb-1">Email</p>
                  <p>{orderData.shippingInfo.email}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Order Summary */}
        <div className="border rounded-lg p-6 mb-8">
          <h2 className="text-2xl mb-6">Chi tiết đơn hàng</h2>
          
          {/* Products List */}
          <div className="space-y-4 mb-6">
            {orderData.items.map((item: any) => (
              <div key={`${item.id}-${item.color}-${item.size}`} className="flex gap-4 pb-4 border-b">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-20 h-20 object-cover rounded"
                />
                <div className="flex-1">
                  <p className="mb-1">{item.name}</p>
                  <p className="text-sm text-gray-600">
                    {item.color && `Màu: ${item.color}`}
                    {item.color && item.size && " • "}
                    {item.size && `Size: ${item.size}`}
                  </p>
                  <p className="text-sm text-gray-600">Số lượng: {item.quantity}</p>
                </div>
                <div className="text-right">
                  <p>{formatPrice(item.price * item.quantity)}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Price Breakdown */}
          <div className="space-y-3 border-t pt-4">
            <div className="flex justify-between">
              <span className="text-gray-600">Tạm tính</span>
              <span>{formatPrice(orderData.subtotal)}</span>
            </div>
            {orderData.discount > 0 && (
              <div className="flex justify-between text-green-600">
                <span>Giảm giá {orderData.coupon && `(${orderData.coupon})`}</span>
                <span>-{formatPrice(orderData.discount)}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-gray-600">Phí vận chuyển</span>
              <span className="text-[#2B6377]">
                {orderData.shipping > 0 ? formatPrice(orderData.shipping) : "Miễn phí"}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Thuế (10%)</span>
              <span>{formatPrice(orderData.tax)}</span>
            </div>
            <div className="border-t pt-3 flex justify-between">
              <span className="text-xl">Tổng cộng</span>
              <span className="text-xl">{formatPrice(orderData.total)}</span>
            </div>
            <div className="pt-2">
              <p className="text-sm text-gray-600">
                Phương thức thanh toán: {orderData.paymentMethod === 'card' ? 'Thẻ tín dụng/Ghi nợ' :
                  orderData.paymentMethod === 'paypal' ? 'PayPal' :
                  orderData.paymentMethod === 'bank' ? 'Chuyển khoản ngân hàng' :
                  orderData.paymentMethod === 'ewallet' ? 'Ví điện tử' :
                  orderData.paymentMethod === 'cod' ? 'Thanh toán khi nhận hàng (COD)' : ''}
              </p>
            </div>
          </div>
        </div>

        {/* Support Information */}
        <div className="bg-[#FAF6F1] rounded-lg p-6 mb-8">
          <h3 className="text-xl mb-4">Cần hỗ trợ?</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600 mb-2">Hotline hỗ trợ khách hàng</p>
              <p className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                1900 xxxx (7:00 - 22:00)
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-2">Email hỗ trợ</p>
              <p className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                support@beaute-cosmetics.com
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/shop">
            <Button
              size="lg"
              className="bg-[#2B6377] hover:bg-[#2B6377]/90 text-white w-full sm:w-auto"
            >
              Tiếp tục mua sắm
            </Button>
          </Link>
          <Link to="/">
            <Button
              variant="outline"
              size="lg"
              className="w-full sm:w-auto border-[#2B6377] text-[#2B6377] hover:bg-[#CCDFE3]"
            >
              Về trang chủ
            </Button>
          </Link>
        </div>
      </div>

      <Footer />
    </div>
  );
}