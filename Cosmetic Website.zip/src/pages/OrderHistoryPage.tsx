import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Navbar } from "../components/Navbar";
import { Footer } from "../components/Footer";
import { Button } from "../components/ui/button";
import { useUser } from "../contexts/UserContext";
import { useOrder, Order } from "../contexts/OrderContext";
import { useLanguage } from "../contexts/LanguageContext";
import { 
  Package, 
  Truck, 
  CheckCircle, 
  XCircle, 
  Clock,
  ExternalLink,
  Copy,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { toast } from "sonner@2.0.3";

export function OrderHistoryPage() {
  const { user } = useUser();
  const { orders: allOrders } = useOrder();
  const { formatPrice } = useLanguage();
  const navigate = useNavigate();
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }
  }, [user, navigate]);

  // Filter orders for current user - include both logged-in and guest orders if needed
  const userOrders = user 
    ? allOrders.filter(order => order.userId === user.id) 
    : [];

  console.log("User:", user);
  console.log("All Orders:", allOrders);
  console.log("User Orders:", userOrders);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Đã sao chép!");
  };

  const openViettelPostTracking = (trackingNumber: string) => {
    window.open(`https://viettelpost.com.vn/tra-cuu-hanh-trinh-don/?code=${trackingNumber}`, '_blank');
  };

  const getStatusIcon = (status: Order["status"]) => {
    switch (status) {
      case "processing":
        return <Clock className="h-5 w-5 text-yellow-600" />;
      case "shipped":
        return <Truck className="h-5 w-5 text-blue-600" />;
      case "delivered":
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case "cancelled":
        return <XCircle className="h-5 w-5 text-red-600" />;
    }
  };

  const getStatusText = (status: Order["status"]) => {
    switch (status) {
      case "processing":
        return "Đang xử lý";
      case "shipped":
        return "Đang giao hàng";
      case "delivered":
        return "Đã giao hàng";
      case "cancelled":
        return "Đã hủy";
    }
  };

  const getStatusColor = (status: Order["status"]) => {
    switch (status) {
      case "processing":
        return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "shipped":
        return "bg-blue-100 text-blue-800 border-blue-300";
      case "delivered":
        return "bg-green-100 text-green-800 border-green-300";
      case "cancelled":
        return "bg-red-100 text-red-800 border-red-300";
    }
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center gap-4 mb-8">
          <Package className="h-10 w-10 text-[#2B6377]" />
          <div>
            <h1 className="text-4xl">Lịch sử đơn hàng</h1>
            <p className="text-gray-600">Xem và theo dõi đơn hàng của bạn</p>
          </div>
        </div>

        {userOrders.length === 0 ? (
          <div className="text-center py-20">
            <Package className="h-20 w-20 text-gray-300 mx-auto mb-4" />
            <h2 className="text-2xl mb-4">Chưa có đơn hàng nào</h2>
            <p className="text-gray-600 mb-8">
              Bạn chưa thực hiện đơn hàng nào. Hãy bắt đầu mua sắm ngay!
            </p>
            <Link to="/shop">
              <Button
                size="lg"
                className="bg-[#2B6377] hover:bg-[#2B6377]/90 text-white"
              >
                Mua sắm ngay
              </Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {userOrders.map((order) => (
              <div
                key={order.orderId}
                className="border rounded-lg overflow-hidden"
              >
                {/* Order Header */}
                <div className="bg-[#FAF6F1] p-6 border-b">
                  <div className="flex flex-wrap items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      {getStatusIcon(order.status)}
                      <div>
                        <p className="text-sm text-gray-600">Mã đơn hàng</p>
                        <p className="font-medium">{order.orderNumber}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600">Ngày đặt</p>
                      <p className="font-medium">
                        {new Date(order.createdAt).toLocaleDateString('vi-VN')}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600">Tổng tiền</p>
                      <p className="font-medium text-xl">{formatPrice(order.total)}</p>
                    </div>
                    <div>
                      <div className={`px-4 py-2 rounded-full border ${getStatusColor(order.status)}`}>
                        {getStatusText(order.status)}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Order Details (Collapsible) */}
                <div className="p-6">
                  {/* Tracking Number */}
                  <div className="mb-6 p-4 bg-[#CCDFE3] rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Truck className="h-5 w-5 text-[#2B6377]" />
                        <p className="font-medium">Mã vận đơn Viettel Post</p>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => openViettelPostTracking(order.trackingNumber)}
                        className="bg-[#2B6377] hover:bg-[#2B6377]/90 text-white flex items-center gap-2"
                      >
                        <ExternalLink className="h-4 w-4" />
                        Tra cứu
                      </Button>
                    </div>
                    <div className="flex items-center gap-2">
                      <p className="text-xl">{order.trackingNumber}</p>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyToClipboard(order.trackingNumber)}
                        className="hover:bg-white/50"
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Toggle Details Button */}
                  <Button
                    variant="ghost"
                    onClick={() => setExpandedOrder(expandedOrder === order.orderId ? null : order.orderId)}
                    className="w-full flex items-center justify-center gap-2 mb-4"
                  >
                    {expandedOrder === order.orderId ? (
                      <>
                        Ẩn chi tiết <ChevronUp className="h-4 w-4" />
                      </>
                    ) : (
                      <>
                        Xem chi tiết <ChevronDown className="h-4 w-4" />
                      </>
                    )}
                  </Button>

                  {/* Expanded Details */}
                  {expandedOrder === order.orderId && (
                    <div className="space-y-6">
                      {/* Products List */}
                      <div>
                        <h3 className="text-xl mb-4">Sản phẩm</h3>
                        <div className="space-y-3">
                          {order.items.map((item, index) => (
                            <div key={index} className="flex gap-4 pb-3 border-b">
                              <img
                                src={item.image}
                                alt={item.name}
                                className="w-20 h-20 object-cover rounded"
                              />
                              <div className="flex-1">
                                <p className="mb-1">{item.name}</p>
                                <p className="text-sm text-gray-600">
                                  {item.color && `Màu: ${item.color}`}
                                  {item.color && item.size && " • "}
                                  {item.size && `Size: ${item.size}`}
                                </p>
                                <p className="text-sm text-gray-600">Số lượng: {item.quantity}</p>
                              </div>
                              <div className="text-right">
                                <p>{formatPrice(item.price * item.quantity)}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Price Breakdown */}
                      <div>
                        <h3 className="text-xl mb-4">Chi tiết giá</h3>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-gray-600">Tạm tính</span>
                            <span>{formatPrice(order.subtotal)}</span>
                          </div>
                          {order.discount > 0 && (
                            <div className="flex justify-between text-green-600">
                              <span>Giảm giá {order.coupon && `(${order.coupon})`}</span>
                              <span>-{formatPrice(order.discount)}</span>
                            </div>
                          )}
                          <div className="flex justify-between">
                            <span className="text-gray-600">Phí vận chuyển</span>
                            <span>{order.shipping > 0 ? formatPrice(order.shipping) : "Miễn phí"}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Thuế (10%)</span>
                            <span>{formatPrice(order.tax)}</span>
                          </div>
                          <div className="border-t pt-2 flex justify-between">
                            <span className="text-xl">Tổng cộng</span>
                            <span className="text-xl">{formatPrice(order.total)}</span>
                          </div>
                        </div>
                      </div>

                      {/* Shipping Info */}
                      <div>
                        <h3 className="text-xl mb-4">Thông tin giao hàng</h3>
                        <div className="bg-gray-50 p-4 rounded-lg">
                          <p><strong>Người nhận:</strong> {order.shippingInfo.fullName}</p>
                          <p><strong>Địa chỉ:</strong> {order.shippingInfo.address}, {order.shippingInfo.city}</p>
                          <p><strong>Điện thoại:</strong> {order.shippingInfo.phone}</p>
                          <p><strong>Email:</strong> {order.shippingInfo.email}</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}