import { Navbar } from "../components/Navbar";
import { Footer } from "../components/Footer";
import { useWishlist } from "../contexts/WishlistContext";
import { useCart } from "../contexts/CartContext";
import { useLanguage } from "../contexts/LanguageContext";
import { Button } from "../components/ui/button";
import { Heart, ShoppingCart, Trash2 } from "lucide-react";
import { Link } from "react-router-dom";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { toast } from "sonner";

export function WishlistPage() {
  const { wishlist, removeFromWishlist } = useWishlist();
  const { addToCart } = useCart();
  const { formatPrice, t } = useLanguage();

  const handleAddToCart = (item: any) => {
    addToCart({
      id: item.id,
      name: item.name,
      price: item.price,
      image: item.image,
      quantity: 1,
    });
    toast.success(t("toast.addedToCart"));
  };

  const handleRemove = (id: number, name: string) => {
    removeFromWishlist(id);
    toast.success(t("toast.removedFromWishlist"));
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="mb-12 text-center">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Heart className="h-8 w-8 text-[#2B6377] fill-[#2B6377]" />
            <h1 className="text-4xl">My Wishlist</h1>
          </div>
          <p className="text-gray-600">
            {wishlist.length} {wishlist.length === 1 ? "item" : "items"} saved for later
          </p>
        </div>

        {wishlist.length === 0 ? (
          <div className="text-center py-20">
            <Heart className="h-20 w-20 text-gray-300 mx-auto mb-6" />
            <h2 className="text-2xl mb-4">Your wishlist is empty</h2>
            <p className="text-gray-600 mb-8">
              Start adding products you love to your wishlist
            </p>
            <Link to="/shop">
              <Button size="lg" className="bg-[#2B6377] hover:bg-[#2B6377]/90 text-white">
                {t("cart.continueShopping")}
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {wishlist.map((item, index) => (
              <div
                key={`wishlist-${item.id}-${index}`}
                className="group bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-xl transition-all duration-300"
              >
                <Link to={`/product/${item.id}`}>
                  <div className="relative aspect-square overflow-hidden bg-gray-100">
                    <ImageWithFallback
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                  </div>
                </Link>

                <div className="p-4">
                  <p className="text-sm text-gray-500 mb-1">{item.category}</p>
                  <Link to={`/product/${item.id}`}>
                    <h3 className="mb-2 hover:text-[#2B6377]">{item.name}</h3>
                  </Link>

                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-xl">{formatPrice(item.price)}</span>
                    {item.originalPrice && (
                      <span className="text-sm text-gray-400 line-through">
                        {formatPrice(item.originalPrice)}
                      </span>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="flex-1 bg-[#2B6377] hover:bg-[#2B6377]/90 text-white"
                      onClick={() => handleAddToCart(item)}
                    >
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      {t("products.addToCart")}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-[#2B6377] text-[#2B6377] hover:bg-[#CCDFE3]"
                      onClick={() => handleRemove(item.id, item.name)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {wishlist.length > 0 && (
          <div className="mt-12 text-center">
            <Link to="/shop">
              <Button variant="outline" size="lg" className="border-[#2B6377] text-[#2B6377] hover:bg-[#CCDFE3]">
                {t("cart.continueShopping")}
              </Button>
            </Link>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}