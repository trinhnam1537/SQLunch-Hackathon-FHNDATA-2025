import { useState, useEffect } from "react";
import { Navbar } from "../components/Navbar";
import { Footer } from "../components/Footer";
import { ProductGrid } from "../components/ProductGrid";
import { ProductFilters } from "../components/ProductFilters";
import { products } from "../data/products";
import { ArrowUpDown } from "lucide-react";
import { useLocation } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";

export function ShopPage() {
  const [filteredProducts, setFilteredProducts] = useState(products);
  const [sortBy, setSortBy] = useState("featured");
  const location = useLocation();
  const { t } = useLanguage();

  // Get search query from URL
  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const searchQuery = searchParams.get("search");
    if (searchQuery) {
      handleFilter({ search: searchQuery });
    }
  }, [location.search]);

  const handleFilter = (filters: any) => {
    let filtered = [...products];

    // Filter by category
    if (filters.category && filters.category !== "All") {
      filtered = filtered.filter((p) => p.category === filters.category);
    }

    // Filter by price range
    if (filters.priceRange) {
      const [min, max] = filters.priceRange;
      filtered = filtered.filter((p) => p.price >= min && p.price <= max);
    }

    // Filter by color
    if (filters.colors && filters.colors.length > 0) {
      filtered = filtered.filter((p) =>
        p.colors?.some((c) => filters.colors.includes(c))
      );
    }

    // Filter by size
    if (filters.sizes && filters.sizes.length > 0) {
      filtered = filtered.filter((p) =>
        p.sizes?.some((s) => filters.sizes.includes(s))
      );
    }

    // Filter by material
    if (filters.material) {
      filtered = filtered.filter((p) =>
        p.material?.toLowerCase().includes(filters.material.toLowerCase())
      );
    }

    // Search by name
    if (filters.search) {
      filtered = filtered.filter((p) =>
        p.name.toLowerCase().includes(filters.search.toLowerCase())
      );
    }

    // Apply sorting
    applySorting(filtered, sortBy);
  };

  const applySorting = (products: any[], sort: string) => {
    let sorted = [...products];
    
    switch (sort) {
      case "price-low":
        sorted.sort((a, b) => a.price - b.price);
        break;
      case "price-high":
        sorted.sort((a, b) => b.price - a.price);
        break;
      case "name-az":
        sorted.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case "name-za":
        sorted.sort((a, b) => b.name.localeCompare(a.name));
        break;
      case "rating":
        sorted.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      default:
        // featured - keep original order
        break;
    }
    
    setFilteredProducts(sorted);
  };

  const handleSortChange = (newSort: string) => {
    setSortBy(newSort);
    applySorting(filteredProducts, newSort);
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-4xl mb-8">{t("nav.shop")}</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <ProductFilters onFilter={handleFilter} />
          </div>
          
          <div className="lg:col-span-3">
            <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <p className="text-gray-600">
                {t("common.showing")} <span className="font-semibold">{filteredProducts.length}</span> {t("common.products")}
              </p>
              
              {/* Sort Dropdown */}
              <div className="flex items-center gap-3">
                <ArrowUpDown className="h-4 w-4 text-gray-600" />
                <select
                  value={sortBy}
                  onChange={(e) => handleSortChange(e.target.value)}
                  className="border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                >
                  <option value="featured">{t("sort.featured")}</option>
                  <option value="price-low">{t("sort.priceLowHigh")}</option>
                  <option value="price-high">{t("sort.priceHighLow")}</option>
                  <option value="name-az">{t("sort.nameAZ")}</option>
                  <option value="name-za">{t("sort.nameZA")}</option>
                  <option value="rating">{t("sort.rating")}</option>
                </select>
              </div>
            </div>
            
            {filteredProducts.length > 0 ? (
              <ProductGrid products={filteredProducts} />
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg mb-4">{t("common.noProducts")}</p>
                <p className="text-gray-400">{t("common.tryDifferentFilters")}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}