import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Navbar } from "../components/Navbar";
import { Footer } from "../components/Footer";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { useCart } from "../contexts/CartContext";
import { useAnalytics } from "../contexts/AnalyticsContext";
import { useLanguage } from "../contexts/LanguageContext";
import { useUser } from "../contexts/UserContext";
import { useOrder } from "../contexts/OrderContext";
import { CreditCard, CheckCircle, Wallet, Building2, Banknote, Smartphone, Tag } from "lucide-react";

type PaymentMethod = "card" | "paypal" | "bank" | "cod" | "ewallet";

// Coupon codes
const COUPONS = {
  "WELCOME10": { discount: 0.1, description: "Giảm 10% cho đơn hàng đầu tiên" },
  "SALE20": { discount: 0.2, description: "Giảm 20% cho tất cả sản phẩm" },
  "FREESHIP": { discount: 0, freeShip: true, description: "Miễn phí vận chuyển" },
  "VIP30": { discount: 0.3, description: "Giảm 30% cho khách hàng VIP" },
};

export function CheckoutPage() {
  const { cart, getTotalPrice, clearCart } = useCart();
  const { trackEvent } = useAnalytics();
  const { formatPrice } = useLanguage();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("card");
  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<keyof typeof COUPONS | null>(null);
  const [couponError, setCouponError] = useState("");
  const [shippingInfo, setShippingInfo] = useState({
    fullName: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    zipCode: "",
  });

  // Shipping fee - 30,000 VND (about $1.2)
  const SHIPPING_FEE = 1.2;

  const applyCoupon = () => {
    const upperCode = couponCode.toUpperCase().trim();
    if (COUPONS[upperCode as keyof typeof COUPONS]) {
      setAppliedCoupon(upperCode as keyof typeof COUPONS);
      setCouponError("");
    } else {
      setCouponError("Mã giảm giá không hợp lệ");
      setAppliedCoupon(null);
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode("");
    setCouponError("");
  };

  const calculateDiscount = () => {
    if (!appliedCoupon) return 0;
    const coupon = COUPONS[appliedCoupon];
    return getTotalPrice() * coupon.discount;
  };

  const calculateShipping = () => {
    if (appliedCoupon && COUPONS[appliedCoupon].freeShip) {
      return 0;
    }
    return SHIPPING_FEE;
  };

  const calculateTotal = () => {
    const subtotal = getTotalPrice();
    const discount = calculateDiscount();
    const shipping = calculateShipping();
    const tax = (subtotal - discount) * 0.1;
    return subtotal - discount + shipping + tax;
  };

  const handlePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    // Simulate payment processing
    setTimeout(() => {
      const orderData = {
        items: cart,
        subtotal: getTotalPrice(),
        discount: calculateDiscount(),
        shipping: calculateShipping(),
        tax: (getTotalPrice() - calculateDiscount()) * 0.1,
        total: calculateTotal(),
        paymentMethod,
        coupon: appliedCoupon,
        shippingInfo,
      };

      trackEvent("payment_success", {
        amount: calculateTotal(),
        items: cart.length,
        method: paymentMethod,
      });

      setIsProcessing(false);
      clearCart();

      // Navigate to order confirmation page with order data
      navigate("/order-confirmation", { state: orderData });
    }, 2000);
  };

  // Redirect to cart if cart is empty
  useEffect(() => {
    if (cart.length === 0) {
      navigate("/cart");
    }
  }, [cart.length, navigate]);

  const paymentMethods = [
    {
      id: "card" as PaymentMethod,
      name: "Thẻ tín dụng/Ghi nợ",
      icon: CreditCard,
      description: "Visa, Mastercard, JCB",
    },
    {
      id: "paypal" as PaymentMethod,
      name: "PayPal",
      icon: Wallet,
      description: "Thanh toán qua PayPal",
    },
    {
      id: "bank" as PaymentMethod,
      name: "Chuyển khoản ngân hàng",
      icon: Building2,
      description: "Chuyển khoản trực tiếp",
    },
    {
      id: "ewallet" as PaymentMethod,
      name: "Ví điện tử",
      icon: Smartphone,
      description: "MoMo, ZaloPay, VNPay",
    },
    {
      id: "cod" as PaymentMethod,
      name: "Thanh toán khi nhận hàng (COD)",
      icon: Banknote,
      description: "Trả tiền mặt khi nhận hàng",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-4xl mb-8">Thanh toán</h1>

        <form onSubmit={handlePayment}>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Shipping & Payment */}
            <div className="lg:col-span-2 space-y-8">
              {/* Shipping Information */}
              <div className="border rounded-lg p-6">
                <h2 className="text-2xl mb-6">Thông tin giao hàng</h2>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="fullName">Họ và tên *</Label>
                      <Input
                        id="fullName"
                        required
                        value={shippingInfo.fullName}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, fullName: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Số điện thoại *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        required
                        value={shippingInfo.phone}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, phone: e.target.value })}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      required
                      value={shippingInfo.email}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, email: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="address">Địa chỉ *</Label>
                    <Input
                      id="address"
                      required
                      value={shippingInfo.address}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, address: e.target.value })}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="city">Thành phố *</Label>
                      <Input
                        id="city"
                        required
                        value={shippingInfo.city}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, city: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="zipCode">Mã bưu điện</Label>
                      <Input
                        id="zipCode"
                        value={shippingInfo.zipCode}
                        onChange={(e) => setShippingInfo({ ...shippingInfo, zipCode: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Payment Method Selection */}
              <div className="border rounded-lg p-6">
                <h2 className="text-2xl mb-6">Phương thức thanh toán</h2>
                <div className="space-y-3">
                  {paymentMethods.map((method) => {
                    const Icon = method.icon;
                    return (
                      <div
                        key={method.id}
                        onClick={() => setPaymentMethod(method.id)}
                        className={`flex items-center gap-4 p-4 border-2 rounded-lg cursor-pointer transition-all ${
                          paymentMethod === method.id
                            ? "border-[#2B6377] bg-[#CCDFE3]"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <input
                          type="radio"
                          name="paymentMethod"
                          checked={paymentMethod === method.id}
                          onChange={() => setPaymentMethod(method.id)}
                          className="w-4 h-4 text-[#2B6377]"
                        />
                        <Icon className="h-6 w-6 text-gray-600" />
                        <div className="flex-1">
                          <p className="font-medium">{method.name}</p>
                          <p className="text-sm text-gray-500">{method.description}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Payment Details Forms */}
                <div className="mt-6">
                  {paymentMethod === "card" && (
                    <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                      <div>
                        <Label htmlFor="cardNumber">Số thẻ *</Label>
                        <Input
                          id="cardNumber"
                          placeholder="1234 5678 9012 3456"
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="cardName">Tên chủ thẻ *</Label>
                        <Input id="cardName" required />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="expiry">Ngày hết hạn *</Label>
                          <Input id="expiry" placeholder="MM/YY" required />
                        </div>
                        <div>
                          <Label htmlFor="cvv">CVV *</Label>
                          <Input id="cvv" placeholder="123" required />
                        </div>
                      </div>
                    </div>
                  )}

                  {paymentMethod === "paypal" && (
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-600 mb-3">
                        Bạn sẽ được chuyển hướng đến PayPal để hoàn tất thanh toán.
                      </p>
                      <div>
                        <Label htmlFor="paypalEmail">Email PayPal *</Label>
                        <Input
                          id="paypalEmail"
                          type="email"
                          placeholder="email@example.com"
                          required
                        />
                      </div>
                    </div>
                  )}

                  {paymentMethod === "bank" && (
                    <div className="p-4 bg-gray-50 rounded-lg space-y-3">
                      <p className="text-sm text-gray-600 mb-3">
                        Vui lòng chuyển khoản đến:
                      </p>
                      <div className="bg-white p-4 rounded border">
                        <p><strong>Ngân hàng:</strong> Vietcombank</p>
                        <p><strong>Số tài khoản:</strong> 1234567890</p>
                        <p><strong>Chủ tài khoản:</strong> BEAUTÉ COSMETICS</p>
                        <p><strong>Nội dung:</strong> [M đơn hàng]</p>
                      </div>
                    </div>
                  )}

                  {paymentMethod === "ewallet" && (
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <Label htmlFor="ewalletType" className="mb-3 block">
                        Chọn ví điện tử *
                      </Label>
                      <select
                        id="ewalletType"
                        className="w-full p-2 border rounded"
                        required
                      >
                        <option value="">-- Chọn ví --</option>
                        <option value="momo">MoMo</option>
                        <option value="zalopay">ZaloPay</option>
                        <option value="vnpay">VNPay</option>
                        <option value="shopeepay">ShopeePay</option>
                      </select>
                      <p className="text-sm text-gray-600 mt-3">
                        Bạn sẽ được chuyển hướng đến ứng dụng ví để thanh toán.
                      </p>
                    </div>
                  )}

                  {paymentMethod === "cod" && (
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <p className="text-sm text-gray-600">
                        Bạn sẽ thanh toán bằng tiền mặt khi nhận hàng. Shipper sẽ liên hệ
                        trước khi giao hàng.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Coupon Code */}
              <div className="border rounded-lg p-6">
                <h2 className="text-2xl mb-6">Mã giảm giá</h2>
                <div className="space-y-3">
                  <div className="flex items-center gap-4">
                    <Input
                      id="couponCode"
                      placeholder="Nhập mã giảm giá"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                    />
                    <Button
                      type="button"
                      size="sm"
                      className="bg-[#2B6377] hover:bg-[#2B6377]/90 text-white"
                      onClick={applyCoupon}
                    >
                      Áp dụng
                    </Button>
                  </div>
                  {couponError && <p className="text-sm text-red-500">{couponError}</p>}
                  {appliedCoupon && (
                    <div className="flex items-center gap-4">
                      <Tag className="h-5 w-5 text-gray-600" />
                      <p className="text-sm text-gray-500">
                        {COUPONS[appliedCoupon].description}
                      </p>
                      <Button
                        type="button"
                        size="sm"
                        className="bg-red-500 hover:bg-red-600 text-white"
                        onClick={removeCoupon}
                      >
                        Xóa
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Right Column - Order Summary */}
            <div className="lg:col-span-1">
              <div className="border rounded-lg p-6 sticky top-4">
                <h2 className="text-2xl mb-6">Đơn hàng</h2>

                {/* Cart Items */}
                <div className="space-y-3 mb-6 max-h-64 overflow-y-auto">
                  {cart.map((item) => (
                    <div key={`${item.id}-${item.color}-${item.size}`} className="flex gap-3">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-16 h-16 object-cover rounded"
                      />
                      <div className="flex-1">
                        <p className="text-sm">{item.name}</p>
                        <p className="text-xs text-gray-500">x{item.quantity}</p>
                      </div>
                      <p className="text-sm">{formatPrice(item.price * item.quantity)}</p>
                    </div>
                  ))}
                </div>

                <div className="space-y-3 mb-6 border-t pt-4">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Tạm tính</span>
                    <span>{formatPrice(getTotalPrice())}</span>
                  </div>
                  {calculateDiscount() > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>Giảm giá {appliedCoupon && `(${appliedCoupon})`}</span>
                      <span>-{formatPrice(calculateDiscount())}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-gray-600">Phí vận chuyển</span>
                    <span className="text-[#2B6377]">
                      {calculateShipping() > 0 ? formatPrice(calculateShipping()) : "Miễn phí"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Thuế (10%)</span>
                    <span>{formatPrice((getTotalPrice() - calculateDiscount()) * 0.1)}</span>
                  </div>
                  <div className="border-t pt-3 flex justify-between">
                    <span className="text-xl">Tổng cộng</span>
                    <span className="text-xl">{formatPrice(calculateTotal())}</span>
                  </div>
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full bg-[#2B6377] hover:bg-[#2B6377]/90 text-white"
                  disabled={isProcessing}
                >
                  {isProcessing ? "Đang xử lý..." : "Hoàn tất thanh toán"}
                </Button>

                <p className="text-xs text-gray-500 text-center mt-4">
                  Bằng cách đặt hàng, bạn đồng ý với điều khoản sử dụng
                </p>
              </div>
            </div>
          </div>
        </form>
      </div>

      <Footer />
    </div>
  );
}