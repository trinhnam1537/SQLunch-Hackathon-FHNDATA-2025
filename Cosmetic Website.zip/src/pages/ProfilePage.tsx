import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Navbar } from "../components/Navbar";
import { Footer } from "../components/Footer";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Checkbox } from "../components/ui/checkbox";
import { useUser } from "../contexts/UserContext";
import { User, Settings, Save } from "lucide-react";
import { toast } from "sonner@2.0.3";

const productCategories = ["Skincare", "Makeup", "Fragrance", "Body Care", "Hair Care"];

export function ProfilePage() {
  const { user, updateProfile, logout } = useUser();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    age: "",
    address: "",
    occupation: "",
    phone: "",
    preferences: [] as string[],
  });
  const [isEditing, setIsEditing] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate("/login");
      return;
    }

    setFormData({
      name: user.name || "",
      email: user.email || "",
      age: user.age?.toString() || "",
      address: user.address || "",
      occupation: user.occupation || "",
      phone: user.phone || "",
      preferences: user.preferences || [],
    });
  }, [user, navigate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    updateProfile({
      name: formData.name,
      age: formData.age ? Number(formData.age) : undefined,
      address: formData.address,
      occupation: formData.occupation,
      phone: formData.phone,
      preferences: formData.preferences,
    });

    setIsEditing(false);
    toast.success("Cập nhật thông tin thành công!");
  };

  const togglePreference = (pref: string) => {
    setFormData((prev) => ({
      ...prev,
      preferences: prev.preferences.includes(pref)
        ? prev.preferences.filter((p) => p !== pref)
        : [...prev.preferences, pref],
    }));
  };

  const handleLogout = () => {
    logout();
    toast.success("Đăng xuất thành công!");
    navigate("/");
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-[#2B6377] rounded-full flex items-center justify-center">
              <User className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl">Thông tin cá nhân</h1>
              <p className="text-gray-600">{user.email}</p>
            </div>
          </div>
          <Button
            variant="outline"
            onClick={handleLogout}
            className="border-[#2B6377] text-[#2B6377] hover:bg-[#CCDFE3]"
          >
            Đăng xuất
          </Button>
        </div>

        <div className="border rounded-lg p-8 bg-[#FAF6F1]">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Settings className="h-5 w-5 text-[#2B6377]" />
              <h2 className="text-2xl">Thông tin tài khoản</h2>
            </div>
            {!isEditing && (
              <Button
                onClick={() => setIsEditing(true)}
                className="bg-[#2B6377] hover:bg-[#2B6377]/90 text-white"
              >
                Chỉnh sửa
              </Button>
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Họ và tên *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  disabled={!isEditing}
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  disabled
                  className="bg-gray-100"
                />
                <p className="text-xs text-gray-500 mt-1">Email không thể thay đổi</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="age">Tuổi</Label>
                <Input
                  id="age"
                  type="number"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  disabled={!isEditing}
                  min="1"
                  max="120"
                />
              </div>
              <div>
                <Label htmlFor="phone">Số điện thoại</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  disabled={!isEditing}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="address">Địa chỉ</Label>
              <Input
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                disabled={!isEditing}
              />
            </div>

            <div>
              <Label htmlFor="occupation">Nghề nghiệp</Label>
              <Input
                id="occupation"
                value={formData.occupation}
                onChange={(e) => setFormData({ ...formData, occupation: e.target.value })}
                disabled={!isEditing}
              />
            </div>

            <div>
              <Label className="mb-3 block">Sở thích sản phẩm</Label>
              <div className="grid grid-cols-2 gap-3">
                {productCategories.map((category) => (
                  <div key={category} className="flex items-center space-x-2">
                    <Checkbox
                      id={category}
                      checked={formData.preferences.includes(category)}
                      onCheckedChange={() => togglePreference(category)}
                      disabled={!isEditing}
                    />
                    <label
                      htmlFor={category}
                      className={isEditing ? "cursor-pointer" : "cursor-not-allowed"}
                    >
                      {category}
                    </label>
                  </div>
                ))}
              </div>
            </div>

            {isEditing && (
              <div className="flex gap-4">
                <Button
                  type="submit"
                  size="lg"
                  className="flex-1 bg-[#2B6377] hover:bg-[#2B6377]/90 text-white flex items-center justify-center gap-2"
                >
                  <Save className="h-4 w-4" />
                  Lưu thay đổi
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  size="lg"
                  className="flex-1 border-[#2B6377] text-[#2B6377] hover:bg-[#CCDFE3]"
                  onClick={() => {
                    setIsEditing(false);
                    // Reset form data
                    if (user) {
                      setFormData({
                        name: user.name || "",
                        email: user.email || "",
                        age: user.age?.toString() || "",
                        address: user.address || "",
                        occupation: user.occupation || "",
                        phone: user.phone || "",
                        preferences: user.preferences || [],
                      });
                    }
                  }}
                >
                  Hủy
                </Button>
              </div>
            )}
          </form>
        </div>

        {/* Account Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
          <div className="border rounded-lg p-6 bg-[#CCDFE3] text-center">
            <p className="text-sm text-gray-600 mb-2">Thành viên từ</p>
            <p className="text-xl">{new Date(user.id).toLocaleDateString('vi-VN')}</p>
          </div>
          <div className="border rounded-lg p-6 bg-[#CCDFE3] text-center">
            <p className="text-sm text-gray-600 mb-2">Sở thích</p>
            <p className="text-xl">{formData.preferences.length} danh mục</p>
          </div>
          <div className="border rounded-lg p-6 bg-[#CCDFE3] text-center">
            <p className="text-sm text-gray-600 mb-2">Trạng thái</p>
            <p className="text-xl">Đang hoạt động</p>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
