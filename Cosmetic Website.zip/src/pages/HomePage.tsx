import { Navbar } from "../components/Navbar";
import { Hero } from "../components/Hero";
import { Categories } from "../components/Categories";
import { FeaturedProducts } from "../components/FeaturedProducts";
import { MostViewedProducts } from "../components/MostViewedProducts";
import { RecommendedProducts } from "../components/RecommendedProducts";
import { BlogPreview } from "../components/BlogPreview";
import { MemberSection } from "../components/MemberSection";
import { Footer } from "../components/Footer";

export function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <Categories />
      <FeaturedProducts />
      <MostViewedProducts />
      <RecommendedProducts />
      <BlogPreview />
      <MemberSection />
      <Footer />
    </div>
  );
}