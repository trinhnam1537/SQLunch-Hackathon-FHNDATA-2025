import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ArrowRight } from "lucide-react";

export function Hero() {
  return (
    <section id="home" className="relative h-[600px] md:h-[700px] overflow-hidden">
      <div className="absolute inset-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1739980296455-3f8d6051ca20?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBjb3NtZXRpY3MlMjBza2luY2FyZXxlbnwxfHx8fDE3NjMzNDAyOTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Luxury cosmetics"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-black/30" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
        <div className="max-w-2xl text-white">
          <p className="mb-4 tracking-wide" style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "0.875rem", fontWeight: 600, color: "#94CCDF" }}>NEW COLLECTION</p>
          <h1 className="mb-6" style={{ fontFamily: "'Playfair Display', serif", fontSize: "4.5rem", fontWeight: 700, lineHeight: 1.2, letterSpacing: "-0.02em" }}>
            Discover Your Natural Beauty
          </h1>
          <p className="mb-8 text-gray-200" style={{ fontFamily: "'Montserrat', sans-serif", fontSize: "1.25rem", fontWeight: 400, lineHeight: 1.7 }}>
            Premium skincare and makeup products crafted with natural ingredients for your radiant glow
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" className="bg-[#2B6377] hover:bg-[#2B6377]/90 text-white">
              Shop Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button size="lg" variant="outline" className="bg-white/90 backdrop-blur-sm border-[#2B6377] text-[#2B6377] hover:bg-[#94CCDF] hover:text-white hover:border-[#94CCDF]">
              Learn More
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}