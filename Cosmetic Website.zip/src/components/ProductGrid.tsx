import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ShoppingCart, Heart, Star } from "lucide-react";
import { useCart } from "../contexts/CartContext";
import { useWishlist } from "../contexts/WishlistContext";
import { useLanguage } from "../contexts/LanguageContext";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";

interface ProductGridProps {
  products: any[];
}

export function ProductGrid({ products }: ProductGridProps) {
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { formatPrice, t } = useLanguage();
  const { addToWishlist, isInWishlist, removeFromWishlist } = useWishlist();

  const handleQuickAdd = (product: any) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
    });
  };

  const toggleFavorite = (product: any) => {
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
      toast.success(t("toast.removedFromWishlist"));
    } else {
      addToWishlist(product);
      toast.success(t("toast.addedToWishlist"));
    }
  };

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600 text-xl">No products found matching your filters</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {products.map((product) => (
        <div
          key={product.id}
          className="group bg-white rounded-lg overflow-hidden border hover:shadow-xl transition-all duration-300"
        >
          <Link to={`/product/${product.id}`}>
            <div className="relative overflow-hidden aspect-square">
              <ImageWithFallback
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              {product.originalPrice && (
                <Badge className="absolute top-3 left-3 bg-[#2B6377] text-white">
                  Sale
                </Badge>
              )}
              <Button
                variant="ghost"
                size="icon"
                className={`absolute top-3 right-3 bg-white/90 hover:bg-white ${
                  isInWishlist(product.id) ? "text-[#2B6377]" : "text-gray-600"
                }`}
                onClick={(e) => {
                  e.preventDefault();
                  toggleFavorite(product);
                }}
              >
                <Heart
                  className="h-5 w-5"
                  fill={isInWishlist(product.id) ? "currentColor" : "none"}
                />
              </Button>
            </div>
          </Link>

          <div className="p-4">
            <p className="text-sm text-gray-500 mb-1">{product.category}</p>
            <Link to={`/product/${product.id}`}>
              <h3 className="mb-2 hover:text-[#2B6377]">{product.name}</h3>
            </Link>

            <div className="flex items-center gap-1 mb-3">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
              <span className="text-sm">{product.rating}</span>
              <span className="text-sm text-gray-500">({product.reviews})</span>
            </div>

            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="text-xl">{formatPrice(product.price)}</span>
                {product.originalPrice && (
                  <span className="text-sm text-gray-400 line-through">
                    {formatPrice(product.originalPrice)}
                  </span>
                )}
              </div>
            </div>

            <Button
              className="w-full bg-[#2B6377] hover:bg-[#2B6377]/90 text-white"
              onClick={() => handleQuickAdd(product)}
              disabled={product.stock === 0}
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              {product.stock > 0 ? t("products.addToCart") : t("common.outOfStock")}
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
}