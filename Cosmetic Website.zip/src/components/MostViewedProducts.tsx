import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Star, TrendingUp } from "lucide-react";
import { Link } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";

const topProducts = [
  {
    id: "1",
    name: "Wireless Bluetooth Headphones",
    category: "Electronics",
    rating: "4.5",
    price: "59.99",
    image: "https://via.placeholder.com/150",
    views: 150,
  },
  {
    id: "2",
    name: "Smartwatch with Heart Rate Monitor",
    category: "Wearable Tech",
    rating: "4.7",
    price: "129.99",
    image: "https://via.placeholder.com/150",
    views: 120,
  },
  {
    id: "3",
    name: "Portable Bluetooth Speaker",
    category: "Audio",
    rating: "4.3",
    price: "39.99",
    image: "https://via.placeholder.com/150",
    views: 100,
  },
  {
    id: "4",
    name: "Smart Home Security Camera",
    category: "Home Security",
    rating: "4.8",
    price: "89.99",
    image: "https://via.placeholder.com/150",
    views: 90,
  },
];

export function MostViewedProducts() {
  const { language } = useLanguage();

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl mb-4">Most Viewed Products</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            See what others are looking at
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {topProducts.map((product) => (
            <Link
              key={product.id}
              to={`/product/${product.id}`}
              className="group bg-white rounded-lg overflow-hidden border hover:shadow-xl transition-all"
            >
              <div className="relative overflow-hidden aspect-square">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <Badge className="absolute top-3 left-3 bg-[#94CCDF] text-[#2B6377] flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  {product.views} views
                </Badge>
              </div>

              <div className="p-4">
                <p className="text-sm text-gray-500 mb-1">{product.category}</p>
                <h3 className="mb-2">{product.name}</h3>
                <div className="flex items-center gap-1 mb-2">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm">{product.rating}</span>
                </div>
                <p className="text-xl">${product.price}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}