import { useState, useRef, useEffect } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { MessageCircle, X, Send, Bot } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { products } from "../data/products";
import { useLanguage } from "../contexts/LanguageContext";
import { Link } from "react-router-dom";

interface Message {
  id: number;
  text: string;
  sender: "user" | "bot";
  products?: any[];
  timestamp: Date;
}

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hi! I'm your beauty assistant. How can I help you today?",
      sender: "bot",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { formatPrice } = useLanguage();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const quickReplies = [
    "Oily skin",
    "Dry skin",
    "Combination skin",
    "Sensitive skin",
    "Anti-aging products",
    "Sunscreen",
  ];

  const analyzeMessage = (message: string): { products: any[]; response: string } => {
    const lowerMessage = message.toLowerCase();
    let recommendedProducts: any[] = [];
    let response = "";

    // Skin type detection
    const skinTypes = {
      "oily skin": ["oily", "oil control", "mattifying", "sebum"],
      "dry skin": ["dry", "hydrating", "moisturizing", "nourishing"],
      "combination skin": ["combination", "balancing"],
      "sensitive skin": ["sensitive", "gentle", "calming", "soothing"],
    };

    // Product type detection
    const productTypes = {
      "cleanser": "cleanser",
      "moisturizer": "moisturizer",
      "serum": "serum",
      "toner": "toner",
      "mask": "mask",
      "sunscreen": "sunscreen",
      "makeup remover": "makeup remover",
      "lipstick": "lipstick",
      "foundation": "foundation",
      "fragrance": "fragrance",
      "anti-aging": "anti-aging",
    };

    let detectedSkinType = "";
    let detectedProductType = "";

    // Detect skin type
    for (const [type, keywords] of Object.entries(skinTypes)) {
      if (lowerMessage.includes(type)) {
        detectedSkinType = type;
        break;
      }
    }

    // Detect product type
    for (const [type, keyword] of Object.entries(productTypes)) {
      if (lowerMessage.includes(type)) {
        detectedProductType = type;
        break;
      }
    }

    // Search products
    if (detectedSkinType || detectedProductType) {
      recommendedProducts = products.filter((product) => {
        const productName = product.name.toLowerCase();
        const productDesc = product.description?.toLowerCase() || "";
        const productMaterial = product.material?.toLowerCase() || "";
        const searchText = `${productName} ${productDesc} ${productMaterial}`;

        let matchesSkinType = true;
        let matchesProductType = true;

        if (detectedSkinType) {
          const keywords = skinTypes[detectedSkinType as keyof typeof skinTypes];
          matchesSkinType = keywords.some((kw) => searchText.includes(kw));
        }

        if (detectedProductType) {
          matchesProductType = lowerMessage.includes(detectedProductType);
        }

        return matchesSkinType && matchesProductType;
      });

      // Fallback to category-based search
      if (recommendedProducts.length === 0) {
        recommendedProducts = products.filter((product) => {
          if (detectedProductType.includes("lipstick") || detectedProductType.includes("foundation")) {
            return product.category === "Makeup";
          }
          if (
            detectedProductType.includes("cleanser") ||
            detectedProductType.includes("moisturizer") ||
            detectedProductType.includes("serum")
          ) {
            return product.category === "Skincare";
          }
          if (detectedProductType.includes("fragrance")) {
            return product.category === "Fragrance";
          }
          return true;
        });
      }

      // Limit to top 3 products
      recommendedProducts = recommendedProducts.slice(0, 3);

      // Generate response
      if (recommendedProducts.length > 0) {
        response = `Great! I found ${recommendedProducts.length} products that match`;
        if (detectedSkinType) response += ` ${detectedSkinType}`;
        if (detectedProductType) response += ` - ${detectedProductType}`;
        response += ` for you:`;
      } else {
        response = `Sorry, I couldn't find any matching products. You can try searching for something else or check out all products on the Shop page.`;
      }
    } else if (
      lowerMessage.includes("hello") ||
      lowerMessage.includes("hi")
    ) {
      response =
        "Hi! I can help you find products. What type of skin do you have and what kind of product are you looking for?";
    } else if (lowerMessage.includes("thank you")) {
      response = "You're welcome! If you need more advice, feel free to ask! 💕";
    } else {
      response =
        "I can help you find products based on your skin type (oily, dry, combination, sensitive) and the type of product you need (cleanser, moisturizer, serum, etc.). Let me know what you're looking for!";
    }

    return { products: recommendedProducts, response };
  };

  const handleSendMessage = () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now(),
      text: input,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    const { products: recommendedProducts, response } = analyzeMessage(input);

    const botMessage: Message = {
      id: Date.now() + 1,
      text: response,
      sender: "bot",
      products: recommendedProducts,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, botMessage]);
  };

  const handleQuickReply = (reply: string) => {
    setInput(reply);
    setTimeout(() => {
      handleSendMessage();
    }, 100);
  };

  return (
    <>
      {/* Floating Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-50 bg-gradient-to-r from-[#2B6377] to-[#94CCDF] text-white rounded-full p-4 shadow-2xl hover:shadow-[#2B6377]/30 hover:scale-110 transition-all duration-300 group"
        >
          <MessageCircle className="h-6 w-6" />
          <span className="absolute -top-1 -right-1 bg-[#94CCDF] text-[#2B6377] text-xs rounded-full h-5 w-5 flex items-center justify-center animate-pulse">
            AI
          </span>
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50 w-96 h-[600px] bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-[#2B6377]/20">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#2B6377] to-[#94CCDF] text-white p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-white/20 rounded-full p-2">
                <Bot className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-semibold">Beauty Assistant</h3>
                <p className="text-xs text-white/80">Always ready to help</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="hover:bg-white/20 rounded-full p-2 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#FAF6F1]">
            {messages.map((message) => (
              <div key={message.id}>
                <div
                  className={`flex ${
                    message.sender === "user" ? "justify-end" : "justify-start"
                  }`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-2 ${
                      message.sender === "user"
                        ? "bg-[#2B6377] text-white rounded-br-none"
                        : "bg-white text-[#2B6377] rounded-bl-none shadow-sm"
                    }`}
                  >
                    <p className="text-sm">{message.text}</p>
                    <p
                      className={`text-xs mt-1 ${
                        message.sender === "user" ? "text-white/70" : "text-[#2B6377]/60"
                      }`}
                    >
                      {message.timestamp.toLocaleTimeString("vi-VN", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                </div>

                {/* Product Recommendations */}
                {message.products && message.products.length > 0 && (
                  <div className="mt-3 space-y-2">
                    {message.products.map((product) => (
                      <Link
                        key={product.id}
                        to={`/product/${product.id}`}
                        onClick={() => setIsOpen(false)}
                      >
                        <div className="bg-white rounded-lg p-3 shadow-sm hover:shadow-md transition-shadow border border-[#2B6377]/20 cursor-pointer">
                          <div className="flex gap-3">
                            <img
                              src={product.image}
                              alt={product.name}
                              className="w-16 h-16 object-cover rounded"
                            />
                            <div className="flex-1">
                              <p className="font-medium text-sm text-[#2B6377]">
                                {product.name}
                              </p>
                              <p className="text-xs text-[#2B6377]/60 line-clamp-1">
                                {product.category}
                              </p>
                              <p className="text-[#2B6377] font-semibold mt-1">
                                {formatPrice(product.price)}
                              </p>
                            </div>
                          </div>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Replies */}
          {messages.length <= 2 && (
            <div className="px-4 py-2 bg-white border-t border-[#2B6377]/20">
              <p className="text-xs text-[#2B6377]/60 mb-2">Suggestions:</p>
              <div className="flex flex-wrap gap-2">
                {quickReplies.map((reply) => (
                  <button
                    key={reply}
                    onClick={() => handleQuickReply(reply)}
                    className="text-xs bg-[#CCDFE3] text-[#2B6377] px-3 py-1 rounded-full hover:bg-[#94CCDF] transition-colors"
                  >
                    {reply}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <div className="p-4 bg-white border-t border-[#2B6377]/20">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex gap-2"
            >
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type a message..."
                className="flex-1"
              />
              <Button
                type="submit"
                size="icon"
                className="bg-[#2B6377] hover:bg-[#94CCDF]"
                disabled={!input.trim()}
              >
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}