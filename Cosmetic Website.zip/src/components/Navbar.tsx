import { Menu, X } from "lucide-react";
import { Button } from "./ui/button";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useCart } from "../contexts/CartContext";
import { useWishlist } from "../contexts/WishlistContext";
import { useUser } from "../contexts/UserContext";
import { useLanguage } from "../contexts/LanguageContext";
import svgPaths from "../imports/svg-y61buv5n1o";

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const { getTotalItems } = useCart();
  const { getTotalWishlistItems } = useWishlist();
  const { user, logout, isAdmin } = useUser();
  const { language, setLanguage, t } = useLanguage();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    setIsUserMenuOpen(false);
    navigate("/");
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/shop?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery("");
    }
  };

  return (
    <nav className="sticky top-0 z-50 bg-gradient-to-l from-9% from-[#ebe4d4] to-96% to-[#bdd4dc] via-43% via-[#c7dedb]" style={{ height: '107px' }}>
      <div className="max-w-[1440px] mx-auto px-8 h-full flex items-center justify-between">
        {/* Logo BEAUTÉ */}
        <Link to="/" className="flex-shrink-0">
          <h1 className="font-['Playfair_Display',sans-serif] text-[#224f5f] text-[36px]" style={{ fontWeight: 700, lineHeight: 'normal' }}>
            BEAUTÉ
          </h1>
        </Link>

        {/* Desktop Navigation Links */}
        <div className="hidden lg:flex items-center gap-8 ml-12">
          <Link to="/" className="font-['Playfair_Display',sans-serif] font-medium text-[#224f5f] text-[28px] hover:text-[#94CCDF] transition-colors">
            {t("nav.home")}
          </Link>
          <Link to="/shop" className="font-['Playfair_Display',sans-serif] font-medium text-[#224f5f] text-[28px] hover:text-[#94CCDF] transition-colors">
            {t("nav.shop")}
          </Link>
          <Link to="/blog" className="font-['Playfair_Display',sans-serif] font-medium text-[#224f5f] text-[28px] hover:text-[#94CCDF] transition-colors">
            {t("nav.blog")}
          </Link>
        </div>

        {/* Search Bar - Desktop */}
        <form onSubmit={handleSearch} className="hidden lg:flex items-center flex-1 max-w-[353px] mx-8">
          <div className="relative w-full h-[38px] flex items-center justify-between px-5 rounded-[30px] border border-[#224f5f]">
            <input
              type="text"
              placeholder="Search here"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 font-['Montserrat',sans-serif] text-[16px] text-[#224f5f] placeholder:text-[#737b8b] outline-none bg-transparent"
            />
            <button type="submit" className="opacity-50 shrink-0 ml-2">
              <div className="w-[20px] h-[20px]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
                  <path d={svgPaths.p6575900} fill="#2E3A59" />
                </svg>
              </div>
            </button>
          </div>
        </form>

        {/* Right Icons */}
        <div className="hidden lg:flex items-center gap-6">
          {/* Language Switcher */}
          <div className="relative">
            <button
              onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
              className="font-['Montserrat',sans-serif] text-[#2B6377] hover:text-[#94CCDF] transition-colors text-sm"
              title="Language"
            >
              {language === "vi" ? "🇻🇳 VI" : "🇬🇧 EN"}
            </button>
            
            {isLangMenuOpen && (
              <div className="absolute right-0 mt-2 w-40 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                <button
                  onClick={() => {
                    setLanguage("vi");
                    setIsLangMenuOpen(false);
                  }}
                  className={`w-full text-left px-4 py-2 hover:bg-gray-100 ${
                    language === "vi" ? "font-bold text-[#2B6377]" : "text-gray-700"
                  }`}
                >
                  🇻🇳 Tiếng Việt
                </button>
                <button
                  onClick={() => {
                    setLanguage("en");
                    setIsLangMenuOpen(false);
                  }}
                  className={`w-full text-left px-4 py-2 hover:bg-gray-100 ${
                    language === "en" ? "font-bold text-[#2B6377]" : "text-gray-700"
                  }`}
                >
                  🇬🇧 English
                </button>
              </div>
            )}
          </div>

          {/* Wishlist Icon */}
          <Link to="/wishlist" className="relative">
            <div className="w-[26px] h-[27px]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 26 27">
                <path d={svgPaths.p257f0b00} stroke="#2B6377" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" className="hover:stroke-[#94CCDF] transition-colors" />
                <path d={svgPaths.p257f0b00} stroke="black" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
              </svg>
            </div>
            {getTotalWishlistItems() > 0 && (
              <span className="absolute -top-2 -right-2 bg-[#2B6377] text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {getTotalWishlistItems()}
              </span>
            )}
          </Link>

          {/* Cart Icon */}
          <Link to="/cart" className="relative">
            <div className="w-[25px] h-[23px]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 23">
                <path d={svgPaths.p32fcc900} stroke="#2B6377" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" className="hover:stroke-[#94CCDF] transition-colors" />
                <path d={svgPaths.p32fcc900} stroke="black" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
                <path d={svgPaths.p21001580} stroke="#2B6377" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" className="hover:stroke-[#94CCDF] transition-colors" />
                <path d={svgPaths.p21001580} stroke="black" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
                <path d={svgPaths.p9a1b980} stroke="#2B6377" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" className="hover:stroke-[#94CCDF] transition-colors" />
                <path d={svgPaths.p9a1b980} stroke="black" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
              </svg>
            </div>
            {getTotalItems() > 0 && (
              <span className="absolute -top-2 -right-2 bg-[#2B6377] text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {getTotalItems()}
              </span>
            )}
          </Link>

          {/* User Icon */}
          {user ? (
            <div className="relative">
              <button
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="hover:opacity-80 transition-opacity"
                title="User Menu"
              >
                <div className="w-[28.659px] h-[25px]">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 25">
                    <path d={svgPaths.pe3f7100} stroke="#2B6377" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" className="hover:stroke-[#94CCDF] transition-colors" />
                    <path d={svgPaths.pe3f7100} stroke="black" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
                    <path d={svgPaths.p5ff980} stroke="#2B6377" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" className="hover:stroke-[#94CCDF] transition-colors" />
                    <path d={svgPaths.p5ff980} stroke="black" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
                  </svg>
                </div>
              </button>
              
              {isUserMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                  <div className="px-4 py-2 border-b border-gray-200">
                    <p className="text-sm font-medium text-[#2B6377]">{user.name}</p>
                    <p className="text-xs text-gray-500">{user.email}</p>
                  </div>
                  <Link
                    to="/profile"
                    className="block text-left px-4 py-2 hover:bg-gray-100 text-gray-700"
                    onClick={() => setIsUserMenuOpen(false)}
                  >
                    {t("nav.profile")}
                  </Link>
                  <Link
                    to="/order-history"
                    className="block text-left px-4 py-2 hover:bg-gray-100 text-gray-700"
                    onClick={() => setIsUserMenuOpen(false)}
                  >
                    {t("nav.orders")}
                  </Link>
                  {isAdmin && (
                    <Link
                      to="/admin"
                      className="block text-left px-4 py-2 hover:bg-gray-100 text-gray-700"
                      onClick={() => setIsUserMenuOpen(false)}
                    >
                      {t("nav.adminDashboard")}
                    </Link>
                  )}
                  <button
                    onClick={handleLogout}
                    className="w-full text-left px-4 py-2 hover:bg-gray-100 text-red-600 border-t border-gray-200 mt-1"
                  >
                    {t("nav.logout")}
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link to="/login">
              <div className="w-[28.659px] h-[25px]">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 25">
                  <path d={svgPaths.pe3f7100} stroke="#2B6377" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" className="hover:stroke-[#94CCDF] transition-colors" />
                  <path d={svgPaths.pe3f7100} stroke="black" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
                  <path d={svgPaths.p5ff980} stroke="#2B6377" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" className="hover:stroke-[#94CCDF] transition-colors" />
                  <path d={svgPaths.p5ff980} stroke="black" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
                </svg>
              </div>
            </Link>
          )}
        </div>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="icon"
          className="lg:hidden text-[#2B6377] hover:bg-white/50"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <Menu className="h-6 w-6" />
        </Button>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="lg:hidden absolute top-[107px] left-0 right-0 bg-white shadow-lg border-t border-[#2B6377]/20 z-50">
          <div className="py-4 px-6 space-y-4">
            <Link
              to="/"
              className="block text-[#2B6377] hover:text-[#94CCDF] transition-colors text-lg"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              to="/shop"
              className="block text-[#2B6377] hover:text-[#94CCDF] transition-colors text-lg"
              onClick={() => setIsMenuOpen(false)}
            >
              Shop
            </Link>
            <Link
              to="/blog"
              className="block text-[#2B6377] hover:text-[#94CCDF] transition-colors text-lg"
              onClick={() => setIsMenuOpen(false)}
            >
              Blog
            </Link>
            {isAdmin && (
              <Link
                to="/admin"
                className="block text-[#2B6377] hover:text-[#94CCDF] transition-colors text-lg"
                onClick={() => setIsMenuOpen(false)}
              >
                Admin Dashboard
              </Link>
            )}
            {!user && (
              <Link
                to="/login"
                className="block text-[#2B6377] hover:text-[#94CCDF] transition-colors text-lg"
                onClick={() => setIsMenuOpen(false)}
              >
                Login
              </Link>
            )}
            
            {/* Mobile Search */}
            <form onSubmit={handleSearch} className="pt-4 border-t border-[#2B6377]/20">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search here"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-4 py-2 border border-[#224f5f] rounded-full focus:outline-none focus:ring-2 focus:ring-[#2B6377]"
                />
                <button type="submit" className="absolute right-3 top-1/2 -translate-y-1/2 opacity-50">
                  <div className="size-[20px]">
                    <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
                      <path d={svgPaths.p6575900} fill="#2E3A59" />
                    </svg>
                  </div>
                </button>
              </div>
            </form>

            {/* Mobile Icons Row */}
            <div className="flex items-center gap-6 pt-4 border-t border-[#2B6377]/20">
              <Link to="/wishlist" className="relative">
                <div className="w-[26px] h-[27px]">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 26 27">
                    <path d={svgPaths.p257f0b00} stroke="#2B6377" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
                  </svg>
                </div>
                {getTotalWishlistItems() > 0 && (
                  <span className="absolute -top-2 -right-2 bg-[#2B6377] text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {getTotalWishlistItems()}
                  </span>
                )}
              </Link>

              <Link to="/cart" className="relative">
                <div className="w-[25px] h-[23px]">
                  <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 23">
                    <path d={svgPaths.p32fcc900} stroke="#2B6377" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
                    <path d={svgPaths.p21001580} stroke="#2B6377" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
                    <path d={svgPaths.p9a1b980} stroke="#2B6377" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
                  </svg>
                </div>
                {getTotalItems() > 0 && (
                  <span className="absolute -top-2 -right-2 bg-[#2B6377] text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {getTotalItems()}
                  </span>
                )}
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}