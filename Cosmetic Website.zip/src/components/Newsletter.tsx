import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Mail } from "lucide-react";
import { useState } from "react";
import { Link } from "react-router-dom";

export function Newsletter() {
  const [email, setEmail] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle newsletter signup
    console.log("Newsletter signup:", email);
    setEmail("");
  };

  return (
    <section className="py-16 bg-[#94CCDF]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="mb-4 text-[#2B6377]" style={{ fontFamily: "'Playfair Display', serif", fontSize: "2rem", fontWeight: 600, lineHeight: 1.3 }}>
          Become a Loyal Member. Join now to receive the earliest promotional information.
        </h2>

        <Link to="/register">
          <Button 
            size="lg" 
            className="bg-[#2B6377] hover:bg-[#2B6377]/90 text-white rounded-full px-8"
            style={{ fontFamily: "'Montserrat', sans-serif", fontWeight: 600 }}
          >
            Let's Connect
          </Button>
        </Link>
      </div>
    </section>
  );
}