import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Star, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import { useLanguage } from "../contexts/LanguageContext";
import { products } from "../data/products";

interface RecommendedProductsProps {
  currentProductId?: number;
}

export function RecommendedProducts({ currentProductId }: RecommendedProductsProps) {
  const { formatPrice } = useLanguage();
}