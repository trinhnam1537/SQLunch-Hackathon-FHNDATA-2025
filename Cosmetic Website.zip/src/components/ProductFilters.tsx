import { useState } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Label } from "./ui/label";
import { Checkbox } from "./ui/checkbox";
import { X, SlidersHorizontal } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";

interface ProductFiltersProps {
  onFilter: (filters: any) => void;
}

const categories = [
  { id: 1, name: "Skincare", count: 45 },
  { id: 2, name: "Makeup", count: 38 },
  { id: 3, name: "Haircare", count: 22 },
  { id: 4, name: "Fragrance", count: 15 },
  { id: 5, name: "Tools & Brushes", count: 18 },
];

const colors = [
  { name: "Red", hex: "#FF0000" },
  { name: "Pink", hex: "#FFC0CB" },
  { name: "Nude", hex: "#E6C9A8" },
  { name: "Brown", hex: "#8B4513" },
  { name: "Purple", hex: "#800080" },
];

const sizes = ["50ml", "100ml", "150ml", "200ml"];

const materials = [
  "Organic",
  "Vegan",
  "Cruelty-Free",
  "Hypoallergenic",
  "Dermatologist Tested",
];

export function ProductFilters({ onFilter }: ProductFiltersProps) {
  const { formatPrice, t } = useLanguage();
  const [filters, setFilters] = useState({
    category: "All",
    priceRange: [0, 200] as [number, number],
    colors: [] as string[],
    sizes: [] as string[],
    material: "",
  });

  const handleFilterChange = (key: string, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFilter(newFilters);
  };

  const toggleColor = (color: string) => {
    const newColors = filters.colors.includes(color)
      ? filters.colors.filter((c) => c !== color)
      : [...filters.colors, color];
    handleFilterChange("colors", newColors);
  };

  const toggleSize = (size: string) => {
    const newSizes = filters.sizes.includes(size)
      ? filters.sizes.filter((s) => s !== size)
      : [...filters.sizes, size];
    handleFilterChange("sizes", newSizes);
  };

  const resetFilters = () => {
    const defaultFilters = {
      category: "All",
      priceRange: [0, 200] as [number, number],
      colors: [],
      sizes: [],
      material: "",
    };
    setFilters(defaultFilters);
    onFilter(defaultFilters);
  };

  const activeFiltersCount =
    (filters.category !== "All" ? 1 : 0) +
    (filters.priceRange[1] !== 200 ? 1 : 0) +
    filters.colors.length +
    filters.sizes.length +
    (filters.material ? 1 : 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="h-5 w-5 text-gray-600" />
          <h3 className="text-xl">{t("common.filter")}</h3>
        </div>
        {activeFiltersCount > 0 && (
          <span className="bg-[#CCDFE3] text-[#2B6377] px-2 py-1 rounded-full text-sm">
            {activeFiltersCount}
          </span>
        )}
      </div>

      {/* Category */}
      <Card className="p-4">
        <Label className="mb-3 block">{t("common.category")}</Label>
        <div className="space-y-2">
          <div
            className={`p-3 rounded-lg cursor-pointer transition-colors ${
              filters.category === "All"
                ? "bg-[#CCDFE3] text-[#2B6377] border border-[#2B6377]/30"
                : "hover:bg-gray-50 border border-transparent"
            }`}
            onClick={() => handleFilterChange("category", "All")}
          >
            <div className="flex justify-between items-center">
              <span>{t("common.all")}</span>
            </div>
          </div>
          {categories.map((cat) => (
            <div
              key={cat.id}
              className={`p-3 rounded-lg cursor-pointer transition-colors ${
                filters.category === cat.name
                  ? "bg-[#CCDFE3] text-[#2B6377] border border-[#2B6377]/30"
                  : "hover:bg-gray-50 border border-transparent"
              }`}
              onClick={() => handleFilterChange("category", cat.name)}
            >
              <div className="flex justify-between items-center">
                <span>{cat.name}</span>
                <span className="text-xs text-gray-500">{cat.count}</span>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Price Range */}
      <Card className="p-4">
        <Label className="mb-3 block">{t("common.priceRange")}</Label>
        <div className="space-y-3">
          <input
            type="range"
            min="0"
            max="200"
            value={filters.priceRange[1]}
            onChange={(e) =>
              handleFilterChange("priceRange", [0, Number(e.target.value)])
            }
            className="w-full"
          />
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-600">{formatPrice(0)}</span>
            <span className="bg-[#CCDFE3] text-[#2B6377] px-3 py-1 rounded-full text-sm">
              {formatPrice(filters.priceRange[1])}
            </span>
          </div>
        </div>
      </Card>

      {/* Colors */}
      <Card className="p-4">
        <Label className="mb-3 block">{t("common.color")}</Label>
        <div className="space-y-2">
          {colors.map((color) => (
            <div
              key={color.name}
              className="flex items-center space-x-3 p-2 hover:bg-gray-50 rounded cursor-pointer"
            >
              <Checkbox
                id={`color-${color.name}`}
                checked={filters.colors.includes(color.name)}
                onCheckedChange={() => toggleColor(color.name)}
              />
              <div
                className="w-5 h-5 rounded-full border-2 border-gray-300 flex-shrink-0"
                style={{ backgroundColor: color.hex }}
              />
              <label
                htmlFor={`color-${color.name}`}
                className="cursor-pointer text-sm flex-1"
              >
                {color.name}
              </label>
            </div>
          ))}
        </div>
      </Card>

      {/* Sizes */}
      <Card className="p-4">
        <Label className="mb-3 block">{t("common.size")}</Label>
        <div className="grid grid-cols-2 gap-2">
          {sizes.map((size) => (
            <div
              key={size}
              onClick={() => toggleSize(size)}
              className={`p-3 text-center rounded-lg border-2 cursor-pointer transition-all ${
                filters.sizes.includes(size)
                  ? "border-[#2B6377] bg-[#CCDFE3] text-[#2B6377]"
                  : "border-gray-200 hover:border-gray-300"
              }`}
            >
              {size}
            </div>
          ))}
        </div>
      </Card>

      {/* Material */}
      <Card className="p-4">
        <Label className="mb-3 block">{t("common.material")}</Label>
        <div className="space-y-2">
          {materials.map((material) => (
            <div
              key={material}
              onClick={() =>
                handleFilterChange(
                  "material",
                  filters.material === material ? "" : material
                )
              }
              className={`p-3 rounded-lg border cursor-pointer transition-all ${
                filters.material === material
                  ? "border-[#2B6377] bg-[#CCDFE3] text-[#2B6377]"
                  : "border-gray-200 hover:border-gray-300"
              }`}
            >
              {material}
            </div>
          ))}
        </div>
      </Card>

      {/* Reset */}
      <Button
        variant="outline"
        className="w-full border-2 border-[#2B6377] text-[#2B6377] hover:bg-[#CCDFE3] hover:border-[#2B6377]"
        onClick={resetFilters}
      >
        <X className="h-4 w-4 mr-2" />
        {t("common.clearFilters")}
      </Button>
    </div>
  );
}