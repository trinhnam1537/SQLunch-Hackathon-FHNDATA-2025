import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

const categories = [
  {
    id: 1,
    name: "Skincare",
    description: "Natural & Organic skincare for radiant skin",
    image: "https://images.unsplash.com/photo-1643379850623-7eb6442cd262?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwc2tpbmNhcmUlMjBib3R0bGVzfGVufDF8fHx8MTc2MzMxNjk3MXww&ixlib=rb-4.1.0&q=80&w=1080",
    count: 156,
  },
  {
    id: 2,
    name: "Makeup",
    description: "Professional makeup products",
    image: "https://images.unsplash.com/photo-1723150512429-bfa92988d845?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWtldXAlMjBwcm9kdWN0cyUyMGJlYXV0eXxlbnwxfHx8fDE3NjMyNzgzMTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    count: 234,
  },
  {
    id: 3,
    name: "Fragrance",
    description: "Luxury perfumes & scents",
    image: "https://images.unsplash.com/photo-1759794108525-94ff060da692?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJmdW1lJTIwYm90dGxlcyUyMGx1eHVyeXxlbnwxfHx8fDE3NjMzMzY2ODd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    count: 89,
  },
  {
    id: 4,
    name: "Body Care",
    description: "Nourishing body products",
    image: "https://images.unsplash.com/photo-1667242003558-e42942d2b911?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWNlJTIwY3JlYW0lMjBqYXJ8ZW58MXx8fHwxNzYzMzA2MzkyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    count: 127,
  },
  {
    id: 5,
    name: "Hair Care",
    description: "Premium hair treatments",
    image: "https://images.unsplash.com/photo-1643379850623-7eb6442cd262?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwc2tpbmNhcmUlMjBib3R0bGVzfGVufDF8fHx8MTc2MzMxNjk3MXww&ixlib=rb-4.1.0&q=80&w=1080",
    count: 98,
  },
];

export function Categories() {
  return (
    <section id="categories" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl mb-4">Danh Mục Sản Phẩm</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Khám phá các nhóm sản phẩm mỹ phẩm cao cấp
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-4">
          {categories.map((category) => (
            <Link key={category.id} to="/shop">
              <div className="group flex items-center gap-6 p-6 bg-white border rounded-lg hover:shadow-xl hover:border-[#2B6377] transition-all duration-300 cursor-pointer">
                {/* Image */}
                <div className="flex-shrink-0 w-24 h-24 md:w-32 md:h-32 rounded-lg overflow-hidden">
                  <ImageWithFallback
                    src={category.image}
                    alt={category.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                </div>

                {/* Content */}
                <div className="flex-1">
                  <h3 className="text-2xl mb-2 group-hover:text-[#2B6377] transition-colors">
                    {category.name}
                  </h3>
                  <p className="text-gray-600 mb-4">{category.description}</p>
                  <p className="text-sm text-gray-500">{category.count}</p>
                </div>

                {/* Arrow */}
                <div className="flex-shrink-0">
                  <ChevronRight className="h-8 w-8 text-gray-400 group-hover:text-[#2B6377] group-hover:translate-x-2 transition-all duration-300" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}