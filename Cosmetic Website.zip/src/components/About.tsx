import { Sparkles, Leaf, Award } from "lucide-react";

const features = [
  {
    icon: Sparkles,
    title: "Premium Quality",
    description: "Only the finest ingredients for your beauty routine"
  },
  {
    icon: Leaf,
    title: "Natural & Organic",
    description: "Eco-friendly and cruelty-free products"
  },
  {
    icon: Award,
    title: "Award Winning",
    description: "Recognized by beauty experts worldwide"
  }
];

export function About() {
  return (
    <section id="about" className="py-20 bg-[#FAF6F1]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl mb-6">
              Your Beauty, Our Passion
            </h2>
            <p className="text-gray-600 mb-6">
              At BEAUTÉ, we believe that beauty starts with quality. Our carefully curated collection features premium cosmetics and skincare products that are as gentle on your skin as they are on the environment.
            </p>
            <p className="text-gray-600 mb-8">
              Each product is selected with care, ensuring that you receive only the best ingredients and formulations. We're committed to helping you discover your natural radiance.
            </p>

            <div className="space-y-6">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div key={index} className="flex gap-4">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-[#2B6377] text-white rounded-full flex items-center justify-center">
                        <Icon className="h-6 w-6" />
                      </div>
                    </div>
                    <div>
                      <h3 className="mb-1">{feature.title}</h3>
                      <p className="text-gray-600">{feature.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div className="bg-white p-8 rounded-lg shadow-md">
                <p className="text-4xl text-[#2B6377] mb-2">500+</p>
                <p className="text-gray-600">Premium Products</p>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-md">
                <p className="text-4xl text-[#2B6377] mb-2">50K+</p>
                <p className="text-gray-600">Happy Customers</p>
              </div>
            </div>
            <div className="space-y-4 mt-8">
              <div className="bg-white p-8 rounded-lg shadow-md">
                <p className="text-4xl text-[#2B6377] mb-2">100%</p>
                <p className="text-gray-600">Natural Ingredients</p>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-md">
                <p className="text-4xl text-[#2B6377] mb-2">24/7</p>
                <p className="text-gray-600">Customer Support</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}