import { useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner@2.0.3";
import svgPaths from "../imports/svg-dk8odrk4vm";
import { Facebook, Instagram, Linkedin, Youtube } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";

export function Footer() {
  const [email, setEmail] = useState("");
  const [agreedToPolicy, setAgreedToPolicy] = useState(false);
  const { t } = useLanguage();

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast.error(t("newsletter.errorEmail"));
      return;
    }
    
    if (!agreedToPolicy) {
      toast.error(t("newsletter.errorPrivacy"));
      return;
    }

    toast.success(t("newsletter.successMessage"));
    setEmail("");
    setAgreedToPolicy(false);
  };

  return (
    <div className="bg-gradient-to-l from-9% from-[#ebe4d4] to-96% to-[#bdd4dc] via-43% via-[#c7dedb] py-12">
      <div className="max-w-[1440px] mx-auto px-8">
        {/* Logo */}
        <Link to="/" className="block mb-8">
          <h1 className="font-['Playfair_Display',sans-serif] text-[#224f5f] text-[36px]" style={{ fontWeight: 700, lineHeight: 'normal' }}>
            BEAUTÉ
          </h1>
        </Link>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 mb-8">
          {/* Company Info - Left */}
          <div className="lg:col-span-3">
            <div className="font-['Montserrat',sans-serif] text-[#224f5f]">
              <p className="font-semibold text-[15px] mb-2">Nourish Skin Caring</p>
              <p className="text-[13px] mb-1">Contact: +84983445678</p>
              <p className="text-[13px] mb-1">Email: nourish.skin@gmail.com</p>
              <p className="text-[13px]">Address: 10 Pham Van Bach, Cau Giay, Ha Noi</p>
            </div>
          </div>

          {/* Newsletter - Center */}
          <div className="lg:col-span-5">
            <div className="font-['Montserrat',sans-serif]">
              <p className="font-semibold text-[#224f5f] text-[15px] mb-4">
                News, resources and insights - delivered to your inbox. Subscribe.
              </p>
              <form onSubmit={handleSubscribe} className="space-y-3">
                {/* Email Input */}
                <div className="bg-white rounded-[30px] border-b-2 border-[#e3e3e3] overflow-hidden">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Leave your email"
                    className="w-full px-5 py-2.5 font-['Montserrat',sans-serif] text-[13px] text-[#224f5f] placeholder:text-[#898989] outline-none"
                  />
                </div>

                {/* Checkbox */}
                <label className="flex items-start gap-3 cursor-pointer">
                  <div className="relative w-4 h-4 mt-0.5 flex-shrink-0">
                    <div className="absolute inset-0 bg-white border border-[#ccdfe3]" />
                    <input
                      type="checkbox"
                      checked={agreedToPolicy}
                      onChange={(e) => setAgreedToPolicy(e.target.checked)}
                      className="absolute inset-0 opacity-0 cursor-pointer"
                    />
                    {agreedToPolicy && (
                      <div className="absolute inset-0 flex items-center justify-center text-[#2B6377]">
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                          <path d="M2 6L5 9L10 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </div>
                    )}
                  </div>
                  <span className="font-['Montserrat',sans-serif] text-[13px] text-[#224f5f]">
                    By checking this box, you agree to the processing of data in accordance with Privacy Policy.
                  </span>
                </label>

                {/* Subscribe Button */}
                <button
                  type="submit"
                  className="px-8 py-2.5 rounded-[32px] font-['Montserrat',sans-serif] font-semibold text-[15px] text-[#ebe4d4] hover:opacity-90 transition-opacity"
                  style={{ backgroundImage: "linear-gradient(90deg, rgba(0, 0, 0, 0.2) 0%, rgba(0, 0, 0, 0.2) 100%), linear-gradient(90deg, rgb(43, 99, 119) 0%, rgb(43, 99, 119) 100%)" }}
                >
                  Subscribe
                </button>
              </form>
            </div>
          </div>

          {/* Footer Columns - Right */}
          <div className="lg:col-span-4 grid grid-cols-1 sm:grid-cols-3 gap-6">
            {/* Get in Touch */}
            <div>
              <h3 className="font-['Montserrat',sans-serif] font-semibold text-[#224f5f] text-[15px] mb-4">
                Get in Touch
              </h3>
              <div className="space-y-2 font-['Montserrat',sans-serif] text-[13px] text-[#224f5f]">
                <Link to="/about" className="block hover:underline">About us</Link>
                <Link to="/contact" className="block hover:underline">Contact us</Link>
                <Link to="/careers" className="block hover:underline">Careers</Link>
                <Link to="/partner" className="block hover:underline">Become a partner</Link>
              </div>
            </div>

            {/* Product */}
            <div>
              <h3 className="font-['Montserrat',sans-serif] font-semibold text-[#224f5f] text-[15px] mb-4">
                Product
              </h3>
              <div className="space-y-2 font-['Montserrat',sans-serif] text-[13px] text-[#224f5f]">
                <Link to="/shop" className="block hover:underline">Products</Link>
                <Link to="/solutions" className="block hover:underline">Solutions</Link>
                <Link to="/integrations" className="block hover:underline">Integrations</Link>
                <Link to="/demos" className="block hover:underline">Quick Demos</Link>
              </div>
            </div>

            {/* Connect */}
            <div>
              <h3 className="font-['Montserrat',sans-serif] font-semibold text-[#224f5f] text-[15px] mb-4">
                Connect
              </h3>
              <div className="space-y-2">
                {/* Facebook */}
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:underline group">
                  <Facebook className="w-[15px] h-[15px] text-[#2B6377] group-hover:scale-110 transition-transform" />
                  <span className="font-['Montserrat',sans-serif] text-[13px] text-[#224f5f]">Facebook</span>
                </a>

                {/* Instagram */}
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:underline group">
                  <Instagram className="w-[15px] h-[15px] text-[#2B6377] group-hover:scale-110 transition-transform" />
                  <span className="font-['Montserrat',sans-serif] text-[13px] text-[#224f5f]">Instagram</span>
                </a>

                {/* LinkedIn */}
                <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:underline group">
                  <Linkedin className="w-[15px] h-[15px] text-[#2B6377] group-hover:scale-110 transition-transform" />
                  <span className="font-['Montserrat',sans-serif] text-[13px] text-[#224f5f]">LinkedIn</span>
                </a>

                {/* YouTube */}
                <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:underline group">
                  <Youtube className="w-[15px] h-[15px] text-[#2B6377] group-hover:scale-110 transition-transform" />
                  <span className="font-['Montserrat',sans-serif] text-[13px] text-[#224f5f]">YouTube</span>
                </a>

                {/* Twitter/X */}
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:underline group">
                  <svg className="w-[15px] h-[15px] text-[#2B6377] group-hover:scale-110 transition-transform" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                  </svg>
                  <span className="font-['Montserrat',sans-serif] text-[13px] text-[#224f5f]">Twitter</span>
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Legals */}
        <div className="border-t border-[#2B6377]/20 pt-6">
          <div className="flex flex-wrap gap-3 sm:gap-5 font-['Montserrat',sans-serif] text-[12px] text-[#767474]">
            <Link to="/trust-legal" className="hover:underline">Trust & Legal Centre</Link>
            <span className="hidden sm:inline">•</span>
            <Link to="/terms" className="hover:underline">Terms & Conditions</Link>
            <span className="hidden sm:inline">•</span>
            <Link to="/privacy" className="hover:underline">Privacy Policy</Link>
            <span className="hidden sm:inline">•</span>
            <Link to="/cookies" className="hover:underline">Cookie Policy</Link>
            <span className="hidden sm:inline">•</span>
            <Link to="/dpa" className="hover:underline">Data Processing Addendum</Link>
            <span className="hidden sm:inline">•</span>
            <Link to="/financial" className="hover:underline">Financial Disclosure Documents</Link>
          </div>
          <p className="font-['Montserrat',sans-serif] text-[12px] text-[#767474] mt-4">
            © {new Date().getFullYear()} Beauté. All rights reserved.
          </p>
        </div>
      </div>
    </div>
  );
}