import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ShoppingCart, Heart, Star } from "lucide-react";
import { useCart } from "../contexts/CartContext";
import { useWishlist } from "../contexts/WishlistContext";
import { useLanguage } from "../contexts/LanguageContext";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";

const products = [
  {
    id: 1,
    name: "Radiance Serum",
    category: "Skincare",
    price: 89.99,
    originalPrice: 119.99,
    rating: 4.8,
    reviews: 234,
    image: "https://images.unsplash.com/photo-1643379850623-7eb6442cd262?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYXR1cmFsJTIwc2tpbmNhcmUlMjBib3R0bGVzfGVufDF8fHx8MTc2MzMxNjk3MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    isNew: true,
    isBestSeller: false
  },
  {
    id: 2,
    name: "Velvet Matte Lipstick",
    category: "Makeup",
    price: 34.99,
    rating: 4.9,
    reviews: 456,
    image: "https://images.unsplash.com/photo-1625093742435-6fa192b6fb10?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsaXBzdGljayUyMG1ha2V1cHxlbnwxfHx8fDE3NjMyNjUyNDV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    isNew: false,
    isBestSeller: true
  },
  {
    id: 3,
    name: "Luxury Eau de Parfum",
    category: "Fragrance",
    price: 149.99,
    rating: 4.7,
    reviews: 189,
    image: "https://images.unsplash.com/photo-1759794108525-94ff060da692?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXJmdW1lJTIwYm90dGxlcyUyMGx1eHVyeXxlbnwxfHx8fDE3NjMzMzY2ODd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    isNew: true,
    isBestSeller: false
  },
  {
    id: 4,
    name: "Hydrating Face Cream",
    category: "Skincare",
    price: 64.99,
    originalPrice: 84.99,
    rating: 4.9,
    reviews: 567,
    image: "https://images.unsplash.com/photo-1667242003558-e42942d2b911?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYWNlJTIwY3JlYW0lMjBqYXJ8ZW58MXx8fHwxNzYzMzA2MzkyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    isNew: false,
    isBestSeller: true
  }
];

export function FeaturedProducts() {
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { formatPrice, t } = useLanguage();
  const { addToWishlist, isInWishlist, removeFromWishlist } = useWishlist();

  const toggleFavorite = (product: any) => {
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id);
      toast.success(t("toast.removedFromWishlist"));
    } else {
      addToWishlist(product);
      toast.success(t("toast.addedToWishlist"));
    }
  };

  const handleAddToCart = (product: any) => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
    });
  };

  return (
    <section id="shop" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-4xl mb-4">Featured Products</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Our most-loved products, handpicked for you
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <div
              key={product.id}
              className="group bg-white rounded-lg overflow-hidden border hover:shadow-xl transition-all duration-300"
            >
              <div className="relative overflow-hidden aspect-square">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3 flex flex-col gap-2">
                  {product.isNew && (
                    <Badge className="bg-[#94CCDF] text-[#2B6377] hover:bg-[#94CCDF]/90">New</Badge>
                  )}
                  {product.isBestSeller && (
                    <Badge className="bg-[#2B6377] text-white hover:bg-[#2B6377]/90">Best Seller</Badge>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className={`absolute top-3 right-3 bg-white/90 hover:bg-white ${
                    isInWishlist(product.id) ? "text-[#2B6377]" : "text-gray-600"
                  }`}
                  onClick={() => toggleFavorite(product)}
                >
                  <Heart
                    className="h-5 w-5"
                    fill={isInWishlist(product.id) ? "currentColor" : "none"}
                  />
                </Button>
              </div>

              <div className="p-4">
                <p className="text-sm text-gray-500 mb-1">{product.category}</p>
                <h3 className="mb-2">{product.name}</h3>

                <div className="flex items-center gap-1 mb-3">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="text-sm">{product.rating}</span>
                  <span className="text-sm text-gray-500">({product.reviews})</span>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{formatPrice(product.price)}</span>
                    {product.originalPrice && (
                      <span className="text-sm text-gray-400 line-through">
                        {formatPrice(product.originalPrice)}
                      </span>
                    )}
                  </div>
                </div>

                <Button
                  className="w-full bg-[#2B6377] hover:bg-[#2B6377]/90 text-white"
                  onClick={() => handleAddToCart(product)}
                >
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  {t("products.addToCart")}
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button
            variant="outline"
            size="lg"
            className="border-[#2B6377] text-[#2B6377] hover:bg-[#2B6377] hover:text-white"
            onClick={() => navigate("/products")}
          >
            {t("products.viewAll")}
          </Button>
        </div>
      </div>
    </section>
  );
}