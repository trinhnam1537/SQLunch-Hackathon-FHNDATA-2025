import { Link } from "react-router-dom";
import { Button } from "./ui/button";

export function MemberSection() {
  return (
    <section className="bg-[#94ccdf] py-16">
      <div className="max-w-[1440px] mx-auto px-8">
        <div className="flex flex-col items-center text-center">
          <p className="font-['Playfair_Display',sans-serif] font-medium text-[28px] text-[rgb(43,99,119)] max-w-[654px] mb-8 leading-normal">
            Become a Loyal Member. Join now to receive the
            earliest promotional information.
          </p>
          <Link to="/register">
            <Button
              size="lg"
              className="px-8 py-2.5 rounded-[32px] font-['Montserrat',sans-serif] font-semibold text-[15px] text-[#FAF6F1] hover:opacity-90 transition-opacity"
              style={{
                backgroundImage:
                  "linear-gradient(90deg, rgba(0, 0, 0, 0.2) 0%, rgba(0, 0, 0, 0.2) 100%), linear-gradient(90deg, rgb(43, 99, 119) 0%, rgb(43, 99, 119) 100%)",
              }}
            >
              Let's Connect
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}