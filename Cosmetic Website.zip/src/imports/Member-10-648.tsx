function Member({ className }: { className?: string }) {
  return (
    <div className={className} data-name="Member">
      <div className="absolute bg-[#94ccdf] h-[228px] left-0 top-0 w-[1440px]" data-name="Subcribe">
        <div className="absolute flex flex-col font-['Playfair_Display:Medium',sans-serif] font-medium h-[106px] justify-center leading-[0] left-1/2 text-[28px] text-black text-center top-[75px] translate-x-[-50%] translate-y-[-50%] w-[654px]">
          <p className="leading-[normal]">Become a Loyal Member. Join now to receive the earliest promotional information.</p>
        </div>
        <div className="absolute h-[60px] left-1/2 rounded-[32px] top-[152px] translate-x-[-50%] w-[236px]" data-name="Link" style={{ backgroundImage: "linear-gradient(90deg, rgba(0, 0, 0, 0.2) 0%, rgba(0, 0, 0, 0.2) 100%), linear-gradient(90deg, rgb(43, 99, 119) 0%, rgb(43, 99, 119) 100%)" }}>
          <div aria-hidden="true" className="absolute border-2 border-[#ccdfe3] border-solid inset-0 pointer-events-none rounded-[32px]" />
          <div className="absolute content-stretch flex flex-col h-[28px] items-center justify-center left-1/2 top-1/2 translate-x-[-50%] translate-y-[-50%]" data-name="span.text-align">
            <div className="h-[32px] relative shrink-0 w-full" data-name="span.h-button-content">
              <div className="absolute flex flex-col font-['Playfair_Display:Medium',sans-serif] font-medium justify-center leading-[0] left-[86px] text-[#ebe4d4] text-[28px] text-center text-nowrap top-[13.5px] translate-x-[-50%] translate-y-[-50%]">
                <p className="leading-[normal] whitespace-pre">Let's Connect</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Member1() {
  return <Member className="relative size-full" />;
}