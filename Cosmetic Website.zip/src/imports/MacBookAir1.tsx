import svgPaths from "./svg-4jegwxvr7m";
import img3DRenderingSpringBackground2321501694891 from "figma:asset/c54164af8d1cf515e3b3c11dc4435e9ba30bcf02.png";

function LogosFacebook() {
  return (
    <div className="absolute left-[138px] size-[20px] top-[565px]" data-name="logos:facebook">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_10_804)" id="logos:facebook">
          <path d={svgPaths.pc8bb400} fill="var(--fill-0, #1877F2)" id="Vector" />
          <path d={svgPaths.p27e9e8f0} fill="var(--fill-0, white)" id="Vector_2" />
        </g>
        <defs>
          <clipPath id="clip0_10_804">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function FlatColorIconsGoogle() {
  return (
    <div className="absolute left-[318px] size-[24px] top-[563px]" data-name="flat-color-icons:google">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="flat-color-icons:google">
          <path d={svgPaths.p257b0b00} fill="var(--fill-0, #FFC107)" id="Vector" />
          <path d={svgPaths.p3347ed00} fill="var(--fill-0, #FF3D00)" id="Vector_2" />
          <path d={svgPaths.p105c8040} fill="var(--fill-0, #4CAF50)" id="Vector_3" />
          <path d={svgPaths.p8514300} fill="var(--fill-0, #1976D2)" id="Vector_4" />
        </g>
      </svg>
    </div>
  );
}

export default function MacBookAir() {
  return (
    <div className="bg-[#dce8ff] relative shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] size-full" data-name="MacBook Air - 1">
      <div className="absolute bg-[#96b8fa] h-[832px] left-[560px] rounded-[416px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25),0px_4px_4px_0px_rgba(0,0,0,0.25)] top-0 w-[1176px]" />
      <div className="absolute bg-[#0f53d7] h-[832px] left-[692px] rounded-[416px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25),0px_4px_4px_0px_rgba(0,0,0,0.25)] top-0 w-[1176px]" />
      <div className="absolute bg-[#003cb0] h-[832px] left-[849px] rounded-[416px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25),0px_4px_4px_0px_rgba(0,0,0,0.25)] top-0 w-[1176px]" />
      <div className="absolute bg-[#96b8fa] h-[645px] left-[66px] rounded-[34px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25),0px_4px_4px_0px_rgba(0,0,0,0.25)] top-[91px] w-[451px]" />
      <p className="absolute font-['Inter:Light',sans-serif] font-['Inter:Semi_Bold',sans-serif] font-light font-semibold leading-[normal] left-[193px] not-italic text-[16px] text-black text-nowrap top-[634px] whitespace-pre">
        <span>{`Not a member? `}</span>
        <span className="[text-decoration-skip-ink:none] [text-underline-position:from-font] decoration-solid text-[#ffc107] underline">Signup now</span>
      </p>
      <p className="[text-shadow:rgba(255,255,255,0.25)_0px_4px_4px] absolute font-['Inter:Extra_Bold',sans-serif] font-extrabold leading-[normal] left-[188px] not-italic text-[40px] text-nowrap text-white top-[148px] whitespace-pre">Login Now</p>
      <div className="absolute bg-[#d9d9d9] left-[108px] size-px top-[255px]" />
      <div className="absolute bg-[#dce8ff] h-[59px] left-[124px] rounded-[10px] top-[255px] w-[335px]" />
      <div className="absolute bg-[#dce8ff] h-[59px] left-[124px] rounded-[10px] top-[344px] w-[335px]" />
      <div className="absolute bg-[#0d43aa] h-[59px] left-[124px] rounded-[10px] top-[433px] w-[335px]" />
      <p className="absolute font-['Inter:Extra_Bold',sans-serif] font-extrabold leading-[normal] left-[241px] not-italic text-[32px] text-nowrap text-white top-[443px] whitespace-pre">LOGIN</p>
      <p className="absolute font-['Inter:Light',sans-serif] font-light leading-[normal] left-[148px] not-italic text-[20px] text-[rgba(0,0,0,0.25)] text-nowrap top-[272px] whitespace-pre">Email or Username</p>
      <p className="absolute font-['Inter:Light',sans-serif] font-light leading-[normal] left-[148px] not-italic text-[20px] text-[rgba(0,0,0,0.25)] text-nowrap top-[361px] whitespace-pre">Password</p>
      <p className="absolute font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[normal] left-[244px] not-italic text-[16px] text-black text-nowrap top-[511px] whitespace-pre">Or login with</p>
      <div className="absolute bg-[#dce8ff] h-[38px] left-[124px] rounded-[10px] top-[556px] w-[155px]" />
      <div className="absolute bg-[#dce8ff] h-[38px] left-[304px] rounded-[10px] top-[556px] w-[155px]" />
      <LogosFacebook />
      <FlatColorIconsGoogle />
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[174px] not-italic text-[#1877f2] text-[16px] text-nowrap top-[566px] whitespace-pre">Facebook</p>
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[normal] left-[354px] not-italic text-[#1976d2] text-[16px] text-nowrap top-[567px] whitespace-pre">Google</p>
      <div className="absolute h-[392px] left-[583px] top-[181px] w-[697px]" data-name="3d-rendering-spring-background_23-2150169489 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={img3DRenderingSpringBackground2321501694891} />
      </div>
      <div className="absolute left-[469px] size-[65px] top-[-22px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 65 65">
          <circle cx="32.5" cy="32.5" id="Ellipse 1" r="27.5" stroke="var(--stroke-0, #003CB0)" strokeOpacity="0.51" strokeWidth="10" />
        </svg>
      </div>
      <div className="absolute left-[66px] size-[82px] top-[791px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 82 82">
          <circle cx="41" cy="41" id="Ellipse 2" r="36" stroke="var(--stroke-0, #003CB0)" strokeOpacity="0.51" strokeWidth="10" />
        </svg>
      </div>
      <div className="absolute left-[478px] size-[82px] top-[673px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 82 82">
          <circle cx="41" cy="41" id="Ellipse 2" r="36" stroke="var(--stroke-0, #003CB0)" strokeOpacity="0.51" strokeWidth="10" />
        </svg>
      </div>
      <div className="absolute left-[719px] size-[82px] top-[155px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 82 82">
          <circle cx="41" cy="41" id="Ellipse 10" r="36" stroke="var(--stroke-0, white)" strokeOpacity="0.51" strokeWidth="10" />
        </svg>
      </div>
      <div className="absolute left-[951px] size-[82px] top-[755px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 82 82">
          <circle cx="41" cy="41" id="Ellipse 10" r="36" stroke="var(--stroke-0, white)" strokeOpacity="0.51" strokeWidth="10" />
        </svg>
      </div>
      <div className="absolute left-[1226px] size-[82px] top-[107px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 82 82">
          <circle cx="41" cy="41" id="Ellipse 10" r="36" stroke="var(--stroke-0, white)" strokeOpacity="0.51" strokeWidth="10" />
        </svg>
      </div>
      <div className="absolute left-[-41px] size-[82px] top-[27px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 82 82">
          <circle cx="41" cy="41" id="Ellipse 2" r="36" stroke="var(--stroke-0, #003CB0)" strokeOpacity="0.51" strokeWidth="10" />
        </svg>
      </div>
      <div className="absolute left-[578px] size-[53px] top-[729px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 53 53">
          <circle cx="26.5" cy="26.5" fill="var(--fill-0, #003CB0)" fillOpacity="0.3" id="Ellipse 7" r="26.5" />
        </svg>
      </div>
      <div className="absolute left-[1214px] size-[53px] top-[492px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 53 53">
          <circle cx="26.5" cy="26.5" fill="var(--fill-0, white)" fillOpacity="0.3" id="Ellipse 11" r="26.5" />
        </svg>
      </div>
      <div className="absolute left-[1007px] size-[53px] top-[43px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 53 53">
          <circle cx="26.5" cy="26.5" fill="var(--fill-0, white)" fillOpacity="0.3" id="Ellipse 11" r="26.5" />
        </svg>
      </div>
      <div className="absolute left-[666px] size-[53px] top-[81px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 53 53">
          <circle cx="26.5" cy="26.5" fill="var(--fill-0, #003CB0)" fillOpacity="0.3" id="Ellipse 7" r="26.5" />
        </svg>
      </div>
      <div className="absolute left-[-12px] size-[53px] top-[409px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 53 53">
          <circle cx="26.5" cy="26.5" fill="var(--fill-0, #003CB0)" fillOpacity="0.3" id="Ellipse 7" r="26.5" />
        </svg>
      </div>
      <div className="absolute left-[398px] size-[53px] top-[-26px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 53 53">
          <circle cx="26.5" cy="26.5" fill="var(--fill-0, #003CB0)" fillOpacity="0.3" id="Ellipse 7" r="26.5" />
        </svg>
      </div>
    </div>
  );
}