import svgPaths from "./svg-dk8odrk4vm";
import imgImage3 from "figma:asset/0272ae94cab582062329f859d79075d024452886.png";

function DivFooterColumnHeading() {
  return (
    <div className="box-border content-stretch flex flex-col items-start pb-[0.5px] pl-0 pr-[36.59px] pt-0 relative shrink-0 w-[128px]" data-name="div.footer-column_heading">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] max-w-[128px] relative shrink-0 text-[#224f5f] text-[15px] text-nowrap">
        <p className="leading-[normal] whitespace-pre">Get in Touch</p>
      </div>
    </div>
  );
}

function Item() {
  return (
    <div className="box-border content-stretch flex flex-col items-start pb-[1.5px] pl-0 pr-[71.3px] pt-[2.5px] relative shrink-0 w-[128px]" data-name="Item">
      <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] max-w-[128px] relative shrink-0 text-[#224f5f] text-[13px] text-nowrap">
        <p className="leading-[normal] whitespace-pre">About us</p>
      </div>
    </div>
  );
}

function Item1() {
  return (
    <div className="box-border content-stretch flex flex-col items-start pb-[1.5px] pl-0 pr-[59.19px] pt-[2.5px] relative shrink-0 w-[128px]" data-name="Item">
      <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] max-w-[128px] relative shrink-0 text-[#224f5f] text-[13px] text-nowrap">
        <p className="leading-[normal] whitespace-pre">Contact us</p>
      </div>
    </div>
  );
}

function Item2() {
  return (
    <div className="box-border content-stretch flex flex-col items-start pb-[1.5px] pl-0 pr-[78.89px] pt-[2.5px] relative shrink-0 w-[128px]" data-name="Item">
      <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] max-w-[128px] relative shrink-0 text-[#224f5f] text-[13px] text-nowrap">
        <p className="leading-[normal] whitespace-pre">Careers</p>
      </div>
    </div>
  );
}

function Item3() {
  return (
    <div className="box-border content-stretch flex flex-col items-start pb-[1.5px] pl-0 pr-[16.45px] pt-[2.5px] relative shrink-0 w-[128px]" data-name="Item">
      <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] max-w-[128px] relative shrink-0 text-[#224f5f] text-[13px] text-nowrap">
        <p className="leading-[normal] whitespace-pre">Become a partner</p>
      </div>
    </div>
  );
}

function List() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full" data-name="List">
      <Item />
      <Item1 />
      <Item2 />
      <Item3 />
    </div>
  );
}

function DivFooterColumnContainer() {
  return (
    <div className="content-stretch flex flex-col gap-[20px] items-start max-w-[152px] relative shrink-0 w-full" data-name="div.footer-column_container">
      <DivFooterColumnHeading />
      <List />
    </div>
  );
}

function DivFooterColumn() {
  return (
    <div className="absolute bottom-[0.5px] box-border content-stretch flex flex-col items-start left-[607px] min-w-[128px] pb-[32px] pt-0 px-0 right-[305px] top-0" data-name="div.footer-column">
      <DivFooterColumnContainer />
    </div>
  );
}

function DivFooterColumnHeading1() {
  return (
    <div className="box-border content-stretch flex flex-col items-start pb-[0.5px] pl-0 pr-[69.53px] pt-0 relative shrink-0" data-name="div.footer-column_heading">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] max-w-[128px] relative shrink-0 text-[#224f5f] text-[15px] text-nowrap">
        <p className="leading-[normal] whitespace-pre">Product</p>
      </div>
    </div>
  );
}

function Item4() {
  return (
    <div className="relative shrink-0 w-full" data-name="Item">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col items-start pb-[1.5px] pl-0 pr-[71.3px] pt-[2.5px] relative w-full">
          <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] max-w-[128px] relative shrink-0 text-[#224f5f] text-[13px] text-nowrap">
            <p className="leading-[normal] whitespace-pre">Products</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Item5() {
  return (
    <div className="relative shrink-0 w-full" data-name="Item">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col items-start pb-[1.5px] pl-0 pr-[69.48px] pt-[2.5px] relative w-full">
          <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] max-w-[128px] relative shrink-0 text-[#224f5f] text-[13px] text-nowrap">
            <p className="leading-[normal] whitespace-pre">Solutions</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Item6() {
  return (
    <div className="relative shrink-0 w-full" data-name="Item">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col items-start pb-[1.5px] pl-0 pr-[52.66px] pt-[2.5px] relative w-full">
          <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] max-w-[128px] relative shrink-0 text-[#224f5f] text-[13px] text-nowrap">
            <p className="leading-[normal] whitespace-pre">Integrations</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Item7() {
  return (
    <div className="relative shrink-0 w-full" data-name="Item">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col items-start pb-[1.5px] pl-0 pr-[44px] pt-[2.5px] relative w-full">
          <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] max-w-[128px] relative shrink-0 text-[#224f5f] text-[13px] text-nowrap">
            <p className="leading-[normal] whitespace-pre">Quick Demos</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function List1() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full" data-name="List">
      <Item4 />
      <Item5 />
      <Item6 />
      <Item7 />
    </div>
  );
}

function DivFooterColumnContainer1() {
  return (
    <div className="content-stretch flex flex-col gap-[20px] items-start max-w-[152px] relative shrink-0 w-full" data-name="div.footer-column_container">
      <DivFooterColumnHeading1 />
      <List1 />
    </div>
  );
}

function DivFooterColumn1() {
  return (
    <div className="absolute box-border content-stretch flex flex-col h-[190.5px] items-start left-[816px] min-w-[128px] pb-[32px] pt-0 px-0 top-0 w-[128px]" data-name="div.footer-column">
      <DivFooterColumnContainer1 />
    </div>
  );
}

function DivFooterColumnHeading2() {
  return (
    <div className="relative shrink-0 w-full" data-name="div.footer-column_heading">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col items-start pb-[0.5px] pl-0 pr-[64.59px] pt-0 relative w-full">
          <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] max-w-[128px] relative shrink-0 text-[#224f5f] text-[15px] text-nowrap">
            <p className="leading-[normal] whitespace-pre">Connect</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Symbols() {
  return (
    <div className="absolute contents inset-0" data-name="Symbols">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 18">
        <g id="Icons/Social">
          <g id="Path">
            <path d={svgPaths.p2a335a80} fill="var(--fill-0, #2B6377)" />
            <path d={svgPaths.p2a335a80} fill="var(--fill-1, black)" fillOpacity="0.2" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Svg() {
  return (
    <div className="h-[18px] overflow-clip relative shrink-0 w-[8px]" data-name="SVG">
      <Symbols />
    </div>
  );
}

function DivTextCenter() {
  return (
    <div className="absolute box-border content-stretch flex flex-col items-center justify-center left-0 px-[4px] py-0 right-0 top-[-3px]" data-name="div.text-center">
      <Svg />
    </div>
  );
}

function DivFooterColumnSocialIcon() {
  return (
    <div className="absolute left-0 size-[15px] top-[5px]" data-name="div.footer-column_social_icon">
      <DivTextCenter />
    </div>
  );
}

function Link() {
  return (
    <div className="absolute h-[21px] left-[23px] top-[2px] w-[33.7px]" data-name="Link">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col h-[21px] items-start pb-px pl-0 pr-[42.27px] pt-0 relative w-[33.7px]">
          <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] max-w-[104px] relative shrink-0 text-[#224f5f] text-[13px] text-nowrap">
            <p className="leading-[normal] whitespace-pre">Facebook</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Item8() {
  return (
    <div className="h-[25px] relative shrink-0 w-full" data-name="Item">
      <DivFooterColumnSocialIcon />
      <Link />
    </div>
  );
}

function IconsSocialInstagram() {
  return (
    <div className="absolute bottom-[3.13%] left-0 right-0 top-[3.13%]" data-name="Icons/Social/Instagram">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g id="Icons/Social/Instagram">
          <g id="Combined-Shape">
            <path d={svgPaths.pfe200f0} fill="var(--fill-0, #2B6377)" />
            <path d={svgPaths.pfe200f0} fill="var(--fill-1, black)" fillOpacity="0.2" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Svg1() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-[15px]" data-name="SVG">
      <IconsSocialInstagram />
    </div>
  );
}

function DivTextCenter1() {
  return (
    <div className="relative shrink-0 w-full" data-name="div.text-center">
      <div className="flex flex-col items-center justify-center size-full">
        <div className="box-border content-stretch flex flex-col items-center justify-center px-[0.5px] py-0 relative w-full">
          <Svg1 />
        </div>
      </div>
    </div>
  );
}

function DivFooterColumnSocialIcon1() {
  return (
    <div className="content-stretch flex flex-col items-start max-h-[15px] max-w-[15px] min-w-[15px] relative shrink-0" data-name="div.footer-column_social_icon">
      <DivTextCenter1 />
    </div>
  );
}

function Link1() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0" data-name="Link">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col items-start pb-px pl-0 pr-[41.12px] pt-0 relative w-full">
          <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] max-w-[104px] relative shrink-0 text-[#224f5f] text-[13px] text-nowrap">
            <p className="leading-[normal] whitespace-pre">Instagram</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Item9() {
  return (
    <div className="content-stretch flex gap-[8px] h-[25px] items-center relative shrink-0 w-full" data-name="Item">
      <DivFooterColumnSocialIcon1 />
      <Link1 />
    </div>
  );
}

function IconsSocial() {
  return (
    <div className="absolute bottom-[5.88%] left-0 right-0 top-[5.88%]" data-name="Icons/Social">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g id="Icons/Social">
          <g id="Shape">
            <path d={svgPaths.p64972e0} fill="var(--fill-0, #2B6377)" />
            <path d={svgPaths.p64972e0} fill="var(--fill-1, black)" fillOpacity="0.2" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Symbols1() {
  return (
    <div className="absolute bottom-[5.88%] contents left-0 right-0 top-[5.88%]" data-name="Symbols">
      <IconsSocial />
    </div>
  );
}

function Svg2() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-[15px]" data-name="SVG">
      <Symbols1 />
    </div>
  );
}

function DivTextCenter2() {
  return (
    <div className="relative shrink-0 w-full" data-name="div.text-center">
      <div className="flex flex-col items-center justify-center size-full">
        <div className="box-border content-stretch flex flex-col items-center justify-center px-[0.5px] py-0 relative w-full">
          <Svg2 />
        </div>
      </div>
    </div>
  );
}

function DivFooterColumnSocialIcon2() {
  return (
    <div className="content-stretch flex flex-col items-start max-h-[15px] max-w-[15px] min-w-[15px] relative shrink-0" data-name="div.footer-column_social_icon">
      <DivTextCenter2 />
    </div>
  );
}

function Link2() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0" data-name="Link">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col items-start pb-px pl-0 pr-[51.45px] pt-0 relative w-full">
          <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] max-w-[104px] relative shrink-0 text-[#224f5f] text-[13px] text-nowrap">
            <p className="leading-[normal] whitespace-pre">LinkedIn</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Item10() {
  return (
    <div className="content-stretch flex gap-[8px] h-[25px] items-center relative shrink-0 w-full" data-name="Item">
      <DivFooterColumnSocialIcon2 />
      <Link2 />
    </div>
  );
}

function Svg3() {
  return (
    <div className="relative shrink-0 size-[15px]" data-name="SVG">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
        <g id="SVG">
          <g id="Vector">
            <path d={svgPaths.p149836f2} fill="var(--fill-0, #2B6377)" />
            <path d={svgPaths.p149836f2} fill="var(--fill-1, black)" fillOpacity="0.2" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function DivTextCenter3() {
  return (
    <div className="relative shrink-0 w-full" data-name="div.text-center">
      <div className="flex flex-col items-center justify-center size-full">
        <div className="box-border content-stretch flex flex-col items-center justify-center px-[0.5px] py-0 relative w-full">
          <Svg3 />
        </div>
      </div>
    </div>
  );
}

function DivFooterColumnSocialIcon3() {
  return (
    <div className="content-stretch flex flex-col items-start max-h-[15px] max-w-[15px] min-w-[15px] relative shrink-0" data-name="div.footer-column_social_icon">
      <DivTextCenter3 />
    </div>
  );
}

function Link3() {
  return (
    <div className="basis-0 grow min-h-px min-w-px relative shrink-0" data-name="Link">
      <div className="size-full">
        <div className="box-border content-stretch flex flex-col items-start pb-px pl-0 pr-[50.73px] pt-0 relative w-full">
          <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] max-w-[104px] relative shrink-0 text-[#224f5f] text-[13px] text-nowrap">
            <p className="leading-[normal] whitespace-pre">YouTube</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Item11() {
  return (
    <div className="content-stretch flex gap-[8px] h-[25px] items-center relative shrink-0 w-full" data-name="Item">
      <DivFooterColumnSocialIcon3 />
      <Link3 />
    </div>
  );
}

function List2() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-full" data-name="List">
      <Item8 />
      <Item9 />
      <Item10 />
      <Item11 />
    </div>
  );
}

function DivFooterColumnContainer2() {
  return (
    <div className="content-stretch flex flex-col gap-[20px] items-start max-w-[152px] relative shrink-0 w-full" data-name="div.footer-column_container">
      <DivFooterColumnHeading2 />
      <List2 />
    </div>
  );
}

function DivFooterColumn2() {
  return (
    <div className="absolute box-border content-stretch flex flex-col h-[190.5px] items-start left-[1008px] min-w-[128px] pb-[15px] pt-0 px-0 top-0 w-[128px]" data-name="div.footer-column">
      <DivFooterColumnContainer2 />
    </div>
  );
}

function DivFooterColumnsDesktop() {
  return (
    <div className="absolute h-[191px] left-[67px] right-[-124px] top-[67px]" data-name="div.footer-columns_desktop">
      <DivFooterColumn />
      <DivFooterColumn1 />
      <DivFooterColumn2 />
    </div>
  );
}

function DivPlaceholder() {
  return (
    <div className="h-[16px] overflow-clip relative shrink-0 w-[385px]" data-name="div#placeholder">
      <div className="absolute flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] left-0 text-[#898989] text-[13px] text-nowrap top-[8px] translate-y-[-50%]">
        <p className="leading-[normal] whitespace-pre">Leave your email</p>
      </div>
    </div>
  );
}

function Input() {
  return (
    <div className="bg-white box-border content-stretch flex items-start justify-center pb-[11.5px] pt-[9.5px] px-0 relative rounded-[30px] shrink-0 w-full" data-name="Input">
      <div aria-hidden="true" className="absolute border-[#e3e3e3] border-[0px_0px_2px] border-solid inset-0 pointer-events-none rounded-[30px]" />
      <DivPlaceholder />
    </div>
  );
}

function P() {
  return <div className="h-[18px] shrink-0 w-[480px]" data-name="p" />;
}

function Label() {
  return (
    <div className="content-stretch flex items-start justify-center relative shrink-0" data-name="Label">
      <P />
    </div>
  );
}

function Label1() {
  return (
    <div className="box-border content-stretch flex flex-col items-start pb-[0.5px] pl-[32px] pr-[74.45px] pt-0 relative self-stretch shrink-0" data-name="Label">
      <div className="absolute bg-white left-0 size-[16px] top-[2px]" data-name="::before">
        <div aria-hidden="true" className="absolute border border-[#ccdfe3] border-solid inset-0 pointer-events-none" />
      </div>
      <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[normal] relative shrink-0 text-[#224f5f] text-[13px] text-nowrap whitespace-pre">
        <p className="mb-0">By checking this box, you agree to the processing of data in</p>
        <p>{`accordance with Employment Hero's Privacy Policy.`}</p>
      </div>
    </div>
  );
}

function DivMktoLogicalField() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-full" data-name="div.mktoLogicalField">
      <Label1 />
    </div>
  );
}

function DivMktoFieldWrap() {
  return (
    <div className="content-stretch flex flex-col gap-[5px] h-[70px] items-start relative shrink-0 w-full" data-name="div.mktoFieldWrap">
      <Label />
      <DivMktoLogicalField />
    </div>
  );
}

function DivMktoFormRow() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[406px]" data-name="div.mktoFormRow">
      <DivMktoFieldWrap />
    </div>
  );
}

function Button() {
  return (
    <div className="box-border content-center flex flex-wrap gap-0 items-center justify-center px-[30px] py-[10px] relative rounded-[32px] self-stretch shrink-0" data-name="Button" style={{ backgroundImage: "linear-gradient(90deg, rgba(0, 0, 0, 0.2) 0%, rgba(0, 0, 0, 0.2) 100%), linear-gradient(90deg, rgb(43, 99, 119) 0%, rgb(43, 99, 119) 100%)" }}>
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#ebe4d4] text-[15px] text-center text-nowrap">
        <p className="leading-[normal] whitespace-pre">Subscribe</p>
      </div>
    </div>
  );
}

function SpanMktoButtonWrap() {
  return (
    <div className="relative shrink-0 w-full" data-name="span.mktoButtonWrap">
      <div className="size-full">
        <div className="box-border content-stretch flex items-start pl-0 pr-[347.44px] py-0 relative w-full">
          <Button />
        </div>
      </div>
    </div>
  );
}

function DivMktoButtonRow() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[137px]" data-name="div.mktoButtonRow">
      <SpanMktoButtonWrap />
    </div>
  );
}

function Form() {
  return (
    <div className="content-stretch flex flex-col gap-[10px] items-start relative shrink-0 w-full" data-name="Form">
      <Input />
      <DivMktoFormRow />
      <DivMktoButtonRow />
    </div>
  );
}

function DivNewsletterSignupForm() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24.5px] items-start left-[182px] top-[calc(50%+30.5px)] translate-y-[-50%] w-[430px]" data-name="div.newsletter_signup-form">
      <div className="flex flex-col font-['Montserrat:SemiBold',sans-serif] font-semibold justify-center leading-[0] relative shrink-0 text-[#224f5f] text-[15px] w-[430px]">
        <p className="leading-[normal]">News, resources and insights - delivered to your inbox. Subscribe.</p>
      </div>
      <Form />
    </div>
  );
}

function DivHContainer() {
  return (
    <div className="absolute h-[286.5px] left-1/2 top-[50px] translate-x-[-50%] w-[1088px]" data-name="div.h-container">
      <DivFooterColumnsDesktop />
      <DivNewsletterSignupForm />
    </div>
  );
}

function Item12() {
  return (
    <div className="box-border content-stretch flex items-start pb-0 pl-0 pr-[3.82px] pt-[2px] relative shrink-0" data-name="Item">
      <div className="flex flex-col font-['Roobert:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#767474] text-[12px] text-nowrap">
        <p className="leading-[18px] whitespace-pre">{`Trust & Legal Centre`}</p>
      </div>
    </div>
  );
}

function Item13() {
  return (
    <div className="box-border content-stretch flex items-start pb-0 pl-0 pr-[3.81px] pt-[2px] relative shrink-0" data-name="Item">
      <div className="flex flex-col font-['Roobert:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#767474] text-[12px] text-nowrap">
        <p className="leading-[18px] whitespace-pre">{`Terms & Conditions`}</p>
      </div>
    </div>
  );
}

function Item14() {
  return (
    <div className="box-border content-stretch flex items-start pb-0 pl-0 pr-[3.82px] pt-[2px] relative shrink-0" data-name="Item">
      <div className="flex flex-col font-['Roobert:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#767474] text-[12px] text-nowrap">
        <p className="leading-[18px] whitespace-pre">Privacy Policy</p>
      </div>
    </div>
  );
}

function Item15() {
  return (
    <div className="box-border content-stretch flex items-start pb-0 pl-0 pr-[3.81px] pt-[2px] relative shrink-0" data-name="Item">
      <div className="flex flex-col font-['Roobert:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#767474] text-[12px] text-nowrap">
        <p className="leading-[18px] whitespace-pre">Cookie Policy</p>
      </div>
    </div>
  );
}

function Item16() {
  return (
    <div className="box-border content-stretch flex items-start pb-0 pl-0 pr-[3.82px] pt-[2px] relative shrink-0" data-name="Item">
      <div className="flex flex-col font-['Roobert:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#767474] text-[12px] text-nowrap">
        <p className="leading-[18px] whitespace-pre">Data Processing Addendum</p>
      </div>
    </div>
  );
}

function List3() {
  return (
    <div className="box-border content-stretch flex gap-[20px] items-end px-0 py-[2px] relative self-stretch shrink-0" data-name="List">
      <Item12 />
      <Item13 />
      <Item14 />
      <Item15 />
      <Item16 />
      <div className="flex flex-col font-['Roobert:Regular',sans-serif] justify-center leading-[0] not-italic relative shrink-0 text-[#767474] text-[12px] text-nowrap">
        <p className="leading-[18px] whitespace-pre">Financial Disclosure Documents</p>
      </div>
    </div>
  );
}

function DivFooterLegals() {
  return (
    <div className="content-stretch flex items-start relative shrink-0" data-name="div.footer-legals">
      <List3 />
    </div>
  );
}

function DivFooterLegalsCountriesContainer() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full" data-name="div.footer-legals_countries_container">
      <DivFooterLegals />
    </div>
  );
}

function DivHContainer1() {
  return (
    <div className="box-border content-stretch flex flex-col items-start max-w-[1088px] px-[24px] py-0 relative shrink-0 w-[1088px]" data-name="div.h-container">
      <DivFooterLegalsCountriesContainer />
    </div>
  );
}

function DivFooterLegalsCountries() {
  return (
    <div className="absolute box-border content-stretch flex flex-col items-center left-0 px-[176px] py-[20px] right-0 top-[336.5px]" data-name="div.footer-legals_countries">
      <DivHContainer1 />
    </div>
  );
}

export default function Footer() {
  return (
    <div className="bg-gradient-to-l from-9% from-[#ebe4d4] relative size-full to-96% to-[#bdd4dc] via-43% via-[#c7dedb]" data-name="Footer">
      <div className="absolute h-[48px] left-[34px] top-[33px] w-[149px]" data-name="BEAUTÉ">
        <div className="absolute flex flex-col font-['Playfair_Display:Bold',sans-serif] font-bold inset-0 justify-center leading-[0] text-[#224f5f] text-[36px]">
          <p className="leading-[normal]">BEAUTÉ</p>
        </div>
      </div>
      <DivHContainer />
      <div className="absolute flex flex-col font-['Montserrat:Regular',sans-serif] font-normal h-[118px] justify-center leading-[normal] left-[46px] text-[#224f5f] text-[0px] top-[186px] translate-y-[-50%] w-[247px]">
        <p className="font-['Montserrat:SemiBold',sans-serif] font-semibold mb-0 text-[15px]">Nourish Skin Caring</p>
        <p className="mb-0 text-[15px]">&nbsp;</p>
        <p className="mb-0 text-[13px]">Contact: +84983445678</p>
        <p className="mb-0 text-[13px]">&nbsp;</p>
        <p className="mb-0 text-[13px]">Email: nourish.skin@gmail.com</p>
        <p className="mb-0 text-[13px]">&nbsp;</p>
        <p className="text-[13px]">Address: 10 Pham Van Bach, Cau Giay, Ha Noi</p>
      </div>
      <DivFooterLegalsCountries />
      <div className="absolute h-[139px] left-[calc(50%-375.5px)] top-[584px] translate-x-[-50%] w-[323px]" data-name="image 3">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage3} />
      </div>
    </div>
  );
}