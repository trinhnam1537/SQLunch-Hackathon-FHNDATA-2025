export default function Rectangle() {
  return <div className="bg-[#96b8fa] rounded-[34px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25),0px_4px_4px_0px_rgba(0,0,0,0.25)] size-full" />;
}