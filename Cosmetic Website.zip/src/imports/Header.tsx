import svgPaths from "./svg-y61buv5n1o";

function Icon() {
  return (
    <div className="absolute h-[25px] left-[1370.34px] top-[40px] w-[28.659px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 29 25">
        <g id="Icon">
          <g id="Vector">
            <path d={svgPaths.pe3f7100} stroke="var(--stroke-0, #2B6377)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
            <path d={svgPaths.pe3f7100} stroke="var(--stroke-1, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
          </g>
          <g id="Vector_2">
            <path d={svgPaths.p5ff980} stroke="var(--stroke-0, #2B6377)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
            <path d={svgPaths.p5ff980} stroke="var(--stroke-1, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Text() {
  return <div className="absolute h-[16px] left-[1258px] top-[43px] w-[103.171px]" data-name="Text" />;
}

function Group() {
  return (
    <div className="absolute contents left-[1258px] top-[40px]">
      <Icon />
      <Text />
    </div>
  );
}

function Icon1() {
  return (
    <div className="absolute h-[27px] left-[1277px] top-[39px] w-[26px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 26 27">
        <g id="Icon">
          <g id="Vector">
            <path d={svgPaths.p257f0b00} stroke="var(--stroke-0, #2B6377)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
            <path d={svgPaths.p257f0b00} stroke="var(--stroke-1, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Favorites() {
  return (
    <div className="absolute contents left-[1277px] top-[39px]" data-name="Favorites">
      <Icon1 />
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents left-[1277px] top-[39px]">
      <Favorites />
    </div>
  );
}

function Categories() {
  return (
    <div className="absolute contents left-[221px] top-[33px]" data-name="Categories">
      <p className="absolute font-['Playfair_Display:Medium',sans-serif] font-medium leading-[normal] left-[221px] text-[#224f5f] text-[28px] text-nowrap top-[33px] whitespace-pre">Home</p>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[221px] top-[33px]">
      <Categories />
    </div>
  );
}

function Categories1() {
  return (
    <div className="absolute contents left-[330px] top-[33px]" data-name="Categories">
      <p className="absolute font-['Playfair_Display:Medium',sans-serif] font-medium leading-[normal] left-[330px] text-[#224f5f] text-[28px] text-nowrap top-[33px] whitespace-pre">Shop</p>
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute contents left-[330px] top-[33px]">
      <Categories1 />
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents left-[221px] top-[33px]">
      <p className="absolute font-['Playfair_Display:Medium',sans-serif] font-medium leading-[normal] left-[430px] text-[#224f5f] text-[28px] text-nowrap top-[33px] whitespace-pre">Blog</p>
      <Group />
      <Group1 />
      <Group3 />
      <Group4 />
    </div>
  );
}

function Icon2() {
  return (
    <div className="absolute h-[23px] left-[1324px] top-[41px] w-[25px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 25 23">
        <g id="Icon">
          <g id="Vector">
            <path d={svgPaths.p32fcc900} stroke="var(--stroke-0, #2B6377)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
            <path d={svgPaths.p32fcc900} stroke="var(--stroke-1, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
          </g>
          <g id="Vector_2">
            <path d={svgPaths.p21001580} stroke="var(--stroke-0, #2B6377)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
            <path d={svgPaths.p21001580} stroke="var(--stroke-1, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
          </g>
          <g id="Vector_3">
            <path d={svgPaths.p9a1b980} stroke="var(--stroke-0, #2B6377)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
            <path d={svgPaths.p9a1b980} stroke="var(--stroke-1, black)" strokeLinecap="round" strokeLinejoin="round" strokeOpacity="0.2" strokeWidth="1.66667" />
          </g>
        </g>
      </svg>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents left-[530px] top-[38px]">
      <div className="absolute box-border content-stretch flex h-[38px] items-center justify-between left-[530px] px-[20px] py-0 rounded-[30px] top-[38px] w-[353px]" data-name="Search">
        <div aria-hidden="true" className="absolute border border-[#224f5f] border-solid inset-0 pointer-events-none rounded-[30px]" />
        <div className="flex flex-col font-['Montserrat:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#737b8b] text-[16px] text-nowrap">
          <p className="leading-[1.6px] whitespace-pre">Search here</p>
        </div>
        <div className="opacity-50 overflow-clip relative shrink-0 size-[20px]" data-name="edit / search">
          <div className="absolute inset-[12.5%_16.28%_18.3%_14.52%]" data-name="coolicon">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
              <path d={svgPaths.p6575900} fill="var(--fill-0, #2E3A59)" id="coolicon" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents left-[530px] top-[38px]">
      <Group2 />
    </div>
  );
}

export default function Header() {
  return (
    <div className="bg-gradient-to-l from-9% from-[#ebe4d4] relative size-full to-96% to-[#bdd4dc] via-43% via-[#c7dedb]" data-name="Header">
      <Group5 />
      <Icon2 />
      <div className="absolute h-[48px] left-[33px] top-[29px] w-[149px]" data-name="BEAUTÉ">
        <div className="absolute flex flex-col font-['Playfair_Display:Bold',sans-serif] font-bold inset-0 justify-center leading-[0] text-[#224f5f] text-[36px]">
          <p className="leading-[normal]">BEAUTÉ</p>
        </div>
      </div>
      <Group6 />
    </div>
  );
}